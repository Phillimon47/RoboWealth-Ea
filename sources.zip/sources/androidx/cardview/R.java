package androidx.cardview;

public final class R {

    public static final class attr {
        public static int cardBackgroundColor = 2130903199;
        public static int cardCornerRadius = 2130903200;
        public static int cardElevation = 2130903201;
        public static int cardMaxElevation = 2130903203;
        public static int cardPreventCornerOverlap = 2130903204;
        public static int cardUseCompatPadding = 2130903205;
        public static int cardViewStyle = 2130903206;
        public static int contentPadding = 2130903366;
        public static int contentPaddingBottom = 2130903367;
        public static int contentPaddingLeft = 2130903369;
        public static int contentPaddingRight = 2130903370;
        public static int contentPaddingTop = 2130903372;

        private attr() {
        }
    }

    public static final class color {
        public static int cardview_dark_background = 2131034168;
        public static int cardview_light_background = 2131034169;
        public static int cardview_shadow_end_color = 2131034170;
        public static int cardview_shadow_start_color = 2131034171;

        private color() {
        }
    }

    public static final class dimen {
        public static int cardview_compat_inset_shadow = 2131099730;
        public static int cardview_default_elevation = 2131099731;
        public static int cardview_default_radius = 2131099732;

        private dimen() {
        }
    }

    public static final class style {
        public static int Base_CardView = 2131886096;
        public static int CardView = 2131886368;
        public static int CardView_Dark = 2131886369;
        public static int CardView_Light = 2131886370;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] CardView = {16843071, 16843072, com.example.snipereambatha.R.attr.cardBackgroundColor, com.example.snipereambatha.R.attr.cardCornerRadius, com.example.snipereambatha.R.attr.cardElevation, com.example.snipereambatha.R.attr.cardMaxElevation, com.example.snipereambatha.R.attr.cardPreventCornerOverlap, com.example.snipereambatha.R.attr.cardUseCompatPadding, com.example.snipereambatha.R.attr.contentPadding, com.example.snipereambatha.R.attr.contentPaddingBottom, com.example.snipereambatha.R.attr.contentPaddingLeft, com.example.snipereambatha.R.attr.contentPaddingRight, com.example.snipereambatha.R.attr.contentPaddingTop};
        public static int CardView_android_minHeight = 1;
        public static int CardView_android_minWidth = 0;
        public static int CardView_cardBackgroundColor = 2;
        public static int CardView_cardCornerRadius = 3;
        public static int CardView_cardElevation = 4;
        public static int CardView_cardMaxElevation = 5;
        public static int CardView_cardPreventCornerOverlap = 6;
        public static int CardView_cardUseCompatPadding = 7;
        public static int CardView_contentPadding = 8;
        public static int CardView_contentPaddingBottom = 9;
        public static int CardView_contentPaddingLeft = 10;
        public static int CardView_contentPaddingRight = 11;
        public static int CardView_contentPaddingTop = 12;

        private styleable() {
        }
    }

    private R() {
    }
}
