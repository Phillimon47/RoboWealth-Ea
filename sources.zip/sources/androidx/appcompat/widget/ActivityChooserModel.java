package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ActivityChooserModel extends DataSetObservable {
    static final String ATTRIBUTE_ACTIVITY = "activity";
    static final String ATTRIBUTE_TIME = "time";
    static final String ATTRIBUTE_WEIGHT = "weight";
    static final boolean DEBUG = false;
    private static final int DEFAULT_ACTIVITY_INFLATION = 5;
    private static final float DEFAULT_HISTORICAL_RECORD_WEIGHT = 1.0f;
    public static final String DEFAULT_HISTORY_FILE_NAME = "activity_choser_model_history.xml";
    public static final int DEFAULT_HISTORY_MAX_LENGTH = 50;
    private static final String HISTORY_FILE_EXTENSION = ".xml";
    private static final int INVALID_INDEX = -1;
    static final String LOG_TAG = ActivityChooserModel.class.getSimpleName();
    static final String TAG_HISTORICAL_RECORD = "historical-record";
    static final String TAG_HISTORICAL_RECORDS = "historical-records";
    private static final Map<String, ActivityChooserModel> sDataModelRegistry = new HashMap();
    private static final Object sRegistryLock = new Object();
    private final List<ActivityResolveInfo> mActivities = new ArrayList();
    private OnChooseActivityListener mActivityChoserModelPolicy;
    private ActivitySorter mActivitySorter = new DefaultSorter();
    boolean mCanReadHistoricalData = true;
    final Context mContext;
    private final List<HistoricalRecord> mHistoricalRecords = new ArrayList();
    private boolean mHistoricalRecordsChanged = true;
    final String mHistoryFileName;
    private int mHistoryMaxSize = 50;
    private final Object mInstanceLock = new Object();
    private Intent mIntent;
    private boolean mReadShareHistoryCalled = false;
    private boolean mReloadActivities = false;

    public interface ActivityChooserModelClient {
        void setActivityChooserModel(ActivityChooserModel activityChooserModel);
    }

    public interface ActivitySorter {
        void sort(Intent intent, List<ActivityResolveInfo> list, List<HistoricalRecord> list2);
    }

    public interface OnChooseActivityListener {
        boolean onChooseActivity(ActivityChooserModel activityChooserModel, Intent intent);
    }

    public static ActivityChooserModel get(Context context, String historyFileName) {
        ActivityChooserModel dataModel;
        synchronized (sRegistryLock) {
            dataModel = sDataModelRegistry.get(historyFileName);
            if (dataModel == null) {
                dataModel = new ActivityChooserModel(context, historyFileName);
                sDataModelRegistry.put(historyFileName, dataModel);
            }
        }
        return dataModel;
    }

    private ActivityChooserModel(Context context, String historyFileName) {
        this.mContext = context.getApplicationContext();
        if (TextUtils.isEmpty(historyFileName) || historyFileName.endsWith(HISTORY_FILE_EXTENSION)) {
            this.mHistoryFileName = historyFileName;
        } else {
            this.mHistoryFileName = historyFileName + HISTORY_FILE_EXTENSION;
        }
    }

    public void setIntent(Intent intent) {
        synchronized (this.mInstanceLock) {
            if (this.mIntent != intent) {
                this.mIntent = intent;
                this.mReloadActivities = true;
                ensureConsistentState();
            }
        }
    }

    public Intent getIntent() {
        Intent intent;
        synchronized (this.mInstanceLock) {
            intent = this.mIntent;
        }
        return intent;
    }

    public int getActivityCount() {
        int size;
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            size = this.mActivities.size();
        }
        return size;
    }

    public ResolveInfo getActivity(int index) {
        ResolveInfo resolveInfo;
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            resolveInfo = this.mActivities.get(index).resolveInfo;
        }
        return resolveInfo;
    }

    public int getActivityIndex(ResolveInfo activity) {
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            List<ActivityResolveInfo> activities = this.mActivities;
            int activityCount = activities.size();
            for (int i = 0; i < activityCount; i++) {
                if (activities.get(i).resolveInfo == activity) {
                    return i;
                }
            }
            return -1;
        }
    }

    public Intent chooseActivity(int index) {
        synchronized (this.mInstanceLock) {
            if (this.mIntent == null) {
                return null;
            }
            ensureConsistentState();
            ActivityResolveInfo chosenActivity = this.mActivities.get(index);
            ComponentName chosenName = new ComponentName(chosenActivity.resolveInfo.activityInfo.packageName, chosenActivity.resolveInfo.activityInfo.name);
            Intent choiceIntent = new Intent(this.mIntent);
            choiceIntent.setComponent(chosenName);
            if (this.mActivityChoserModelPolicy != null) {
                if (this.mActivityChoserModelPolicy.onChooseActivity(this, new Intent(choiceIntent))) {
                    return null;
                }
            }
            addHistoricalRecord(new HistoricalRecord(chosenName, System.currentTimeMillis(), 1.0f));
            return choiceIntent;
        }
    }

    public void setOnChooseActivityListener(OnChooseActivityListener listener) {
        synchronized (this.mInstanceLock) {
            this.mActivityChoserModelPolicy = listener;
        }
    }

    public ResolveInfo getDefaultActivity() {
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            if (this.mActivities.isEmpty()) {
                return null;
            }
            ResolveInfo resolveInfo = this.mActivities.get(0).resolveInfo;
            return resolveInfo;
        }
    }

    public void setDefaultActivity(int index) {
        float weight;
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            ActivityResolveInfo newDefaultActivity = this.mActivities.get(index);
            ActivityResolveInfo oldDefaultActivity = this.mActivities.get(0);
            if (oldDefaultActivity != null) {
                weight = (oldDefaultActivity.weight - newDefaultActivity.weight) + 5.0f;
            } else {
                weight = 1.0f;
            }
            addHistoricalRecord(new HistoricalRecord(new ComponentName(newDefaultActivity.resolveInfo.activityInfo.packageName, newDefaultActivity.resolveInfo.activityInfo.name), System.currentTimeMillis(), weight));
        }
    }

    private void persistHistoricalDataIfNeeded() {
        if (!this.mReadShareHistoryCalled) {
            throw new IllegalStateException("No preceding call to #readHistoricalData");
        } else if (this.mHistoricalRecordsChanged) {
            this.mHistoricalRecordsChanged = false;
            if (!TextUtils.isEmpty(this.mHistoryFileName)) {
                new PersistHistoryAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[]{new ArrayList(this.mHistoricalRecords), this.mHistoryFileName});
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0015, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setActivitySorter(androidx.appcompat.widget.ActivityChooserModel.ActivitySorter r3) {
        /*
            r2 = this;
            java.lang.Object r0 = r2.mInstanceLock
            monitor-enter(r0)
            androidx.appcompat.widget.ActivityChooserModel$ActivitySorter r1 = r2.mActivitySorter     // Catch:{ all -> 0x0016 }
            if (r1 != r3) goto L_0x0009
            monitor-exit(r0)     // Catch:{ all -> 0x0016 }
            return
        L_0x0009:
            r2.mActivitySorter = r3     // Catch:{ all -> 0x0016 }
            boolean r1 = r2.sortActivitiesIfNeeded()     // Catch:{ all -> 0x0016 }
            if (r1 == 0) goto L_0x0014
            r2.notifyChanged()     // Catch:{ all -> 0x0016 }
        L_0x0014:
            monitor-exit(r0)     // Catch:{ all -> 0x0016 }
            return
        L_0x0016:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0016 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActivityChooserModel.setActivitySorter(androidx.appcompat.widget.ActivityChooserModel$ActivitySorter):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0018, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setHistoryMaxSize(int r3) {
        /*
            r2 = this;
            java.lang.Object r0 = r2.mInstanceLock
            monitor-enter(r0)
            int r1 = r2.mHistoryMaxSize     // Catch:{ all -> 0x0019 }
            if (r1 != r3) goto L_0x0009
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            return
        L_0x0009:
            r2.mHistoryMaxSize = r3     // Catch:{ all -> 0x0019 }
            r2.pruneExcessiveHistoricalRecordsIfNeeded()     // Catch:{ all -> 0x0019 }
            boolean r1 = r2.sortActivitiesIfNeeded()     // Catch:{ all -> 0x0019 }
            if (r1 == 0) goto L_0x0017
            r2.notifyChanged()     // Catch:{ all -> 0x0019 }
        L_0x0017:
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            return
        L_0x0019:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActivityChooserModel.setHistoryMaxSize(int):void");
    }

    public int getHistoryMaxSize() {
        int i;
        synchronized (this.mInstanceLock) {
            i = this.mHistoryMaxSize;
        }
        return i;
    }

    public int getHistorySize() {
        int size;
        synchronized (this.mInstanceLock) {
            ensureConsistentState();
            size = this.mHistoricalRecords.size();
        }
        return size;
    }

    private void ensureConsistentState() {
        boolean stateChanged = loadActivitiesIfNeeded() | readHistoricalDataIfNeeded();
        pruneExcessiveHistoricalRecordsIfNeeded();
        if (stateChanged) {
            sortActivitiesIfNeeded();
            notifyChanged();
        }
    }

    private boolean sortActivitiesIfNeeded() {
        if (this.mActivitySorter == null || this.mIntent == null || this.mActivities.isEmpty() || this.mHistoricalRecords.isEmpty()) {
            return false;
        }
        this.mActivitySorter.sort(this.mIntent, this.mActivities, Collections.unmodifiableList(this.mHistoricalRecords));
        return true;
    }

    private boolean loadActivitiesIfNeeded() {
        if (!this.mReloadActivities || this.mIntent == null) {
            return false;
        }
        this.mReloadActivities = false;
        this.mActivities.clear();
        List<ResolveInfo> resolveInfos = this.mContext.getPackageManager().queryIntentActivities(this.mIntent, 0);
        int resolveInfoCount = resolveInfos.size();
        for (int i = 0; i < resolveInfoCount; i++) {
            this.mActivities.add(new ActivityResolveInfo(resolveInfos.get(i)));
        }
        return true;
    }

    private boolean readHistoricalDataIfNeeded() {
        if (!this.mCanReadHistoricalData || !this.mHistoricalRecordsChanged || TextUtils.isEmpty(this.mHistoryFileName)) {
            return false;
        }
        this.mCanReadHistoricalData = false;
        this.mReadShareHistoryCalled = true;
        readHistoricalDataImpl();
        return true;
    }

    private boolean addHistoricalRecord(HistoricalRecord historicalRecord) {
        boolean added = this.mHistoricalRecords.add(historicalRecord);
        if (added) {
            this.mHistoricalRecordsChanged = true;
            pruneExcessiveHistoricalRecordsIfNeeded();
            persistHistoricalDataIfNeeded();
            sortActivitiesIfNeeded();
            notifyChanged();
        }
        return added;
    }

    private void pruneExcessiveHistoricalRecordsIfNeeded() {
        int pruneCount = this.mHistoricalRecords.size() - this.mHistoryMaxSize;
        if (pruneCount > 0) {
            this.mHistoricalRecordsChanged = true;
            for (int i = 0; i < pruneCount; i++) {
                HistoricalRecord remove = this.mHistoricalRecords.remove(0);
            }
        }
    }

    public static final class HistoricalRecord {
        public final ComponentName activity;
        public final long time;
        public final float weight;

        public HistoricalRecord(String activityName, long time2, float weight2) {
            this(ComponentName.unflattenFromString(activityName), time2, weight2);
        }

        public HistoricalRecord(ComponentName activityName, long time2, float weight2) {
            this.activity = activityName;
            this.time = time2;
            this.weight = weight2;
        }

        public int hashCode() {
            return (((((1 * 31) + (this.activity == null ? 0 : this.activity.hashCode())) * 31) + ((int) (this.time ^ (this.time >>> 32)))) * 31) + Float.floatToIntBits(this.weight);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            HistoricalRecord other = (HistoricalRecord) obj;
            if (this.activity == null) {
                if (other.activity != null) {
                    return false;
                }
            } else if (!this.activity.equals(other.activity)) {
                return false;
            }
            if (this.time == other.time && Float.floatToIntBits(this.weight) == Float.floatToIntBits(other.weight)) {
                return true;
            }
            return false;
        }

        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("[");
            builder.append("; activity:").append(this.activity);
            builder.append("; time:").append(this.time);
            builder.append("; weight:").append(new BigDecimal((double) this.weight));
            builder.append("]");
            return builder.toString();
        }
    }

    public static final class ActivityResolveInfo implements Comparable<ActivityResolveInfo> {
        public final ResolveInfo resolveInfo;
        public float weight;

        public ActivityResolveInfo(ResolveInfo resolveInfo2) {
            this.resolveInfo = resolveInfo2;
        }

        public int hashCode() {
            return Float.floatToIntBits(this.weight) + 31;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj != null && getClass() == obj.getClass() && Float.floatToIntBits(this.weight) == Float.floatToIntBits(((ActivityResolveInfo) obj).weight)) {
                return true;
            }
            return false;
        }

        public int compareTo(ActivityResolveInfo another) {
            return Float.floatToIntBits(another.weight) - Float.floatToIntBits(this.weight);
        }

        public String toString() {
            StringBuilder builder = new StringBuilder();
            builder.append("[");
            builder.append("resolveInfo:").append(this.resolveInfo.toString());
            builder.append("; weight:").append(new BigDecimal((double) this.weight));
            builder.append("]");
            return builder.toString();
        }
    }

    private static final class DefaultSorter implements ActivitySorter {
        private static final float WEIGHT_DECAY_COEFFICIENT = 0.95f;
        private final Map<ComponentName, ActivityResolveInfo> mPackageNameToActivityMap = new HashMap();

        DefaultSorter() {
        }

        public void sort(Intent intent, List<ActivityResolveInfo> activities, List<HistoricalRecord> historicalRecords) {
            Map<ComponentName, ActivityResolveInfo> componentNameToActivityMap = this.mPackageNameToActivityMap;
            componentNameToActivityMap.clear();
            int activityCount = activities.size();
            for (int i = 0; i < activityCount; i++) {
                ActivityResolveInfo activity = activities.get(i);
                activity.weight = 0.0f;
                componentNameToActivityMap.put(new ComponentName(activity.resolveInfo.activityInfo.packageName, activity.resolveInfo.activityInfo.name), activity);
            }
            float nextRecordWeight = 1.0f;
            for (int i2 = historicalRecords.size() - 1; i2 >= 0; i2--) {
                HistoricalRecord historicalRecord = historicalRecords.get(i2);
                ActivityResolveInfo activity2 = componentNameToActivityMap.get(historicalRecord.activity);
                if (activity2 != null) {
                    activity2.weight += historicalRecord.weight * nextRecordWeight;
                    nextRecordWeight *= WEIGHT_DECAY_COEFFICIENT;
                }
            }
            Collections.sort(activities);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x003b, code lost:
        if (r2 == null) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        r2.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void readHistoricalDataImpl() {
        /*
            r12 = this;
            java.lang.String r0 = "Error reading historical recrod file: "
            r1 = 0
            android.content.Context r2 = r12.mContext     // Catch:{ FileNotFoundException -> 0x00d9 }
            java.lang.String r3 = r12.mHistoryFileName     // Catch:{ FileNotFoundException -> 0x00d9 }
            java.io.FileInputStream r2 = r2.openFileInput(r3)     // Catch:{ FileNotFoundException -> 0x00d9 }
            org.xmlpull.v1.XmlPullParser r1 = android.util.Xml.newPullParser()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r3 = "UTF-8"
            r1.setInput(r2, r3)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r3 = 0
        L_0x0016:
            r4 = 1
            if (r3 == r4) goto L_0x0022
            r5 = 2
            if (r3 == r5) goto L_0x0022
            int r4 = r1.next()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r3 = r4
            goto L_0x0016
        L_0x0022:
            java.lang.String r5 = "historical-records"
            java.lang.String r6 = r1.getName()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            boolean r5 = r5.equals(r6)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            if (r5 == 0) goto L_0x0084
            java.util.List<androidx.appcompat.widget.ActivityChooserModel$HistoricalRecord> r5 = r12.mHistoricalRecords     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r5.clear()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
        L_0x0033:
            int r6 = r1.next()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r3 = r6
            if (r3 != r4) goto L_0x0042
            if (r2 == 0) goto L_0x00d0
            r2.close()     // Catch:{ IOException -> 0x00ce }
            goto L_0x00cd
        L_0x0042:
            r6 = 3
            if (r3 == r6) goto L_0x0033
            r6 = 4
            if (r3 != r6) goto L_0x0049
            goto L_0x0033
        L_0x0049:
            java.lang.String r6 = r1.getName()     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r7 = "historical-record"
            boolean r7 = r7.equals(r6)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            if (r7 == 0) goto L_0x007c
            java.lang.String r7 = "activity"
            r8 = 0
            java.lang.String r7 = r1.getAttributeValue(r8, r7)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r9 = "time"
            java.lang.String r9 = r1.getAttributeValue(r8, r9)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            long r9 = java.lang.Long.parseLong(r9)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r11 = "weight"
            java.lang.String r8 = r1.getAttributeValue(r8, r11)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            float r8 = java.lang.Float.parseFloat(r8)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            androidx.appcompat.widget.ActivityChooserModel$HistoricalRecord r11 = new androidx.appcompat.widget.ActivityChooserModel$HistoricalRecord     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r11.<init>((java.lang.String) r7, (long) r9, (float) r8)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            r5.add(r11)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            goto L_0x0033
        L_0x007c:
            org.xmlpull.v1.XmlPullParserException r4 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r7 = "Share records file not well-formed."
            r4.<init>(r7)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            throw r4     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
        L_0x0084:
            org.xmlpull.v1.XmlPullParserException r4 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            java.lang.String r5 = "Share records file does not start with historical-records tag."
            r4.<init>(r5)     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
            throw r4     // Catch:{ XmlPullParserException -> 0x00ae, IOException -> 0x008e }
        L_0x008c:
            r0 = move-exception
            goto L_0x00d1
        L_0x008e:
            r1 = move-exception
            java.lang.String r3 = LOG_TAG     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x008c }
            r4.<init>()     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r0 = r4.append(r0)     // Catch:{ all -> 0x008c }
            java.lang.String r4 = r12.mHistoryFileName     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ all -> 0x008c }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x008c }
            android.util.Log.e(r3, r0, r1)     // Catch:{ all -> 0x008c }
            if (r2 == 0) goto L_0x00d0
            r2.close()     // Catch:{ IOException -> 0x00ce }
            goto L_0x00cd
        L_0x00ae:
            r1 = move-exception
            java.lang.String r3 = LOG_TAG     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x008c }
            r4.<init>()     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r0 = r4.append(r0)     // Catch:{ all -> 0x008c }
            java.lang.String r4 = r12.mHistoryFileName     // Catch:{ all -> 0x008c }
            java.lang.StringBuilder r0 = r0.append(r4)     // Catch:{ all -> 0x008c }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x008c }
            android.util.Log.e(r3, r0, r1)     // Catch:{ all -> 0x008c }
            if (r2 == 0) goto L_0x00d0
            r2.close()     // Catch:{ IOException -> 0x00ce }
        L_0x00cd:
            goto L_0x00d0
        L_0x00ce:
            r0 = move-exception
            goto L_0x00cd
        L_0x00d0:
            return
        L_0x00d1:
            if (r2 == 0) goto L_0x00d8
            r2.close()     // Catch:{ IOException -> 0x00d7 }
            goto L_0x00d8
        L_0x00d7:
            r1 = move-exception
        L_0x00d8:
            throw r0
        L_0x00d9:
            r0 = move-exception
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActivityChooserModel.readHistoricalDataImpl():void");
    }

    private final class PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void> {
        PersistHistoryAsyncTask() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:27:0x00b2 A[SYNTHETIC, Splitter:B:27:0x00b2] */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x00da A[SYNTHETIC, Splitter:B:35:0x00da] */
        /* JADX WARNING: Removed duplicated region for block: B:43:0x0102 A[SYNTHETIC, Splitter:B:43:0x0102] */
        /* JADX WARNING: Removed duplicated region for block: B:51:0x0111 A[SYNTHETIC, Splitter:B:51:0x0111] */
        /* JADX WARNING: Unknown top exception splitter block from list: {B:23:0x0091=Splitter:B:23:0x0091, B:39:0x00e1=Splitter:B:39:0x00e1, B:31:0x00b9=Splitter:B:31:0x00b9} */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Void doInBackground(java.lang.Object... r18) {
            /*
                r17 = this;
                r1 = r17
                java.lang.String r0 = "historical-record"
                java.lang.String r2 = "historical-records"
                java.lang.String r3 = "Error writing historical record file: "
                r4 = 0
                r5 = r18[r4]
                java.util.List r5 = (java.util.List) r5
                r6 = 1
                r7 = r18[r6]
                java.lang.String r7 = (java.lang.String) r7
                r8 = 0
                r9 = 0
                androidx.appcompat.widget.ActivityChooserModel r10 = androidx.appcompat.widget.ActivityChooserModel.this     // Catch:{ FileNotFoundException -> 0x0117 }
                android.content.Context r10 = r10.mContext     // Catch:{ FileNotFoundException -> 0x0117 }
                java.io.FileOutputStream r10 = r10.openFileOutput(r7, r4)     // Catch:{ FileNotFoundException -> 0x0117 }
                org.xmlpull.v1.XmlSerializer r8 = android.util.Xml.newSerializer()
                r8.setOutput(r10, r9)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                java.lang.String r11 = "UTF-8"
                java.lang.Boolean r12 = java.lang.Boolean.valueOf(r6)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                r8.startDocument(r11, r12)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                r8.startTag(r9, r2)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                int r11 = r5.size()     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                r12 = 0
            L_0x0035:
                if (r12 >= r11) goto L_0x006f
                java.lang.Object r13 = r5.remove(r4)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                androidx.appcompat.widget.ActivityChooserModel$HistoricalRecord r13 = (androidx.appcompat.widget.ActivityChooserModel.HistoricalRecord) r13     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                r8.startTag(r9, r0)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                java.lang.String r14 = "activity"
                android.content.ComponentName r15 = r13.activity     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                java.lang.String r15 = r15.flattenToString()     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                r8.attribute(r9, r14, r15)     // Catch:{ IllegalArgumentException -> 0x00de, IllegalStateException -> 0x00b6, IOException -> 0x008e, all -> 0x0088 }
                java.lang.String r14 = "time"
                r16 = r5
                long r4 = r13.time     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                java.lang.String r4 = java.lang.String.valueOf(r4)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                r8.attribute(r9, r14, r4)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                java.lang.String r4 = "weight"
                float r5 = r13.weight     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                java.lang.String r5 = java.lang.String.valueOf(r5)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                r8.attribute(r9, r4, r5)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                r8.endTag(r9, r0)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                int r12 = r12 + 1
                r5 = r16
                r4 = 0
                goto L_0x0035
            L_0x006f:
                r16 = r5
                r8.endTag(r9, r2)     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                r8.endDocument()     // Catch:{ IllegalArgumentException -> 0x0086, IllegalStateException -> 0x0084, IOException -> 0x0082 }
                androidx.appcompat.widget.ActivityChooserModel r0 = androidx.appcompat.widget.ActivityChooserModel.this
                r0.mCanReadHistoricalData = r6
                if (r10 == 0) goto L_0x0108
                r10.close()     // Catch:{ IOException -> 0x0106 }
                goto L_0x0105
            L_0x0082:
                r0 = move-exception
                goto L_0x0091
            L_0x0084:
                r0 = move-exception
                goto L_0x00b9
            L_0x0086:
                r0 = move-exception
                goto L_0x00e1
            L_0x0088:
                r0 = move-exception
                r16 = r5
                r2 = r0
                goto L_0x010b
            L_0x008e:
                r0 = move-exception
                r16 = r5
            L_0x0091:
                java.lang.String r2 = androidx.appcompat.widget.ActivityChooserModel.LOG_TAG     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0109 }
                r4.<init>()     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r4.append(r3)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r4 = androidx.appcompat.widget.ActivityChooserModel.this     // Catch:{ all -> 0x0109 }
                java.lang.String r4 = r4.mHistoryFileName     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0109 }
                java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0109 }
                android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r0 = androidx.appcompat.widget.ActivityChooserModel.this
                r0.mCanReadHistoricalData = r6
                if (r10 == 0) goto L_0x0108
                r10.close()     // Catch:{ IOException -> 0x0106 }
                goto L_0x0105
            L_0x00b6:
                r0 = move-exception
                r16 = r5
            L_0x00b9:
                java.lang.String r2 = androidx.appcompat.widget.ActivityChooserModel.LOG_TAG     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0109 }
                r4.<init>()     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r4.append(r3)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r4 = androidx.appcompat.widget.ActivityChooserModel.this     // Catch:{ all -> 0x0109 }
                java.lang.String r4 = r4.mHistoryFileName     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0109 }
                java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0109 }
                android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r0 = androidx.appcompat.widget.ActivityChooserModel.this
                r0.mCanReadHistoricalData = r6
                if (r10 == 0) goto L_0x0108
                r10.close()     // Catch:{ IOException -> 0x0106 }
                goto L_0x0105
            L_0x00de:
                r0 = move-exception
                r16 = r5
            L_0x00e1:
                java.lang.String r2 = androidx.appcompat.widget.ActivityChooserModel.LOG_TAG     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0109 }
                r4.<init>()     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r4.append(r3)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r4 = androidx.appcompat.widget.ActivityChooserModel.this     // Catch:{ all -> 0x0109 }
                java.lang.String r4 = r4.mHistoryFileName     // Catch:{ all -> 0x0109 }
                java.lang.StringBuilder r3 = r3.append(r4)     // Catch:{ all -> 0x0109 }
                java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0109 }
                android.util.Log.e(r2, r3, r0)     // Catch:{ all -> 0x0109 }
                androidx.appcompat.widget.ActivityChooserModel r0 = androidx.appcompat.widget.ActivityChooserModel.this
                r0.mCanReadHistoricalData = r6
                if (r10 == 0) goto L_0x0108
                r10.close()     // Catch:{ IOException -> 0x0106 }
            L_0x0105:
                goto L_0x0108
            L_0x0106:
                r0 = move-exception
                goto L_0x0105
            L_0x0108:
                return r9
            L_0x0109:
                r0 = move-exception
                r2 = r0
            L_0x010b:
                androidx.appcompat.widget.ActivityChooserModel r0 = androidx.appcompat.widget.ActivityChooserModel.this
                r0.mCanReadHistoricalData = r6
                if (r10 == 0) goto L_0x0116
                r10.close()     // Catch:{ IOException -> 0x0115 }
                goto L_0x0116
            L_0x0115:
                r0 = move-exception
            L_0x0116:
                throw r2
            L_0x0117:
                r0 = move-exception
                r16 = r5
                java.lang.String r2 = androidx.appcompat.widget.ActivityChooserModel.LOG_TAG
                java.lang.StringBuilder r4 = new java.lang.StringBuilder
                r4.<init>()
                java.lang.StringBuilder r3 = r4.append(r3)
                java.lang.StringBuilder r3 = r3.append(r7)
                java.lang.String r3 = r3.toString()
                android.util.Log.e(r2, r3, r0)
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActivityChooserModel.PersistHistoryAsyncTask.doInBackground(java.lang.Object[]):java.lang.Void");
        }
    }
}
