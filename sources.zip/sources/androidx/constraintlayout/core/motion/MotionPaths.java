package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.key.MotionKeyPosition;
import androidx.constraintlayout.core.motion.utils.Easing;
import java.util.Arrays;
import java.util.HashMap;

public class MotionPaths implements Comparable<MotionPaths> {
    public static final int CARTESIAN = 0;
    public static final boolean DEBUG = false;
    static final int OFF_HEIGHT = 4;
    static final int OFF_PATH_ROTATE = 5;
    static final int OFF_POSITION = 0;
    static final int OFF_WIDTH = 3;
    static final int OFF_X = 1;
    static final int OFF_Y = 2;
    public static final boolean OLD_WAY = false;
    public static final int PERPENDICULAR = 1;
    public static final int SCREEN = 2;
    public static final String TAG = "MotionPaths";
    static String[] names = {"position", "x", "y", "width", "height", "pathRotate"};
    HashMap<String, CustomVariable> customAttributes = new HashMap<>();
    float height;
    int mAnimateCircleAngleTo;
    int mAnimateRelativeTo = -1;
    int mDrawPath = 0;
    Easing mKeyFrameEasing;
    int mMode = 0;
    int mPathMotionArc = -1;
    float mPathRotate = Float.NaN;
    float mProgress = Float.NaN;
    float mRelativeAngle = Float.NaN;
    Motion mRelativeToController = null;
    double[] mTempDelta = new double[18];
    double[] mTempValue = new double[18];
    float position;
    float time;
    float width;
    float x;
    float y;

    public MotionPaths() {
    }

    /* access modifiers changed from: package-private */
    public void initCartesian(MotionKeyPosition c, MotionPaths startTimePoint, MotionPaths endTimePoint) {
        MotionKeyPosition motionKeyPosition = c;
        MotionPaths motionPaths = startTimePoint;
        MotionPaths motionPaths2 = endTimePoint;
        float position2 = ((float) motionKeyPosition.mFramePosition) / 100.0f;
        this.time = position2;
        this.mDrawPath = motionKeyPosition.mDrawPath;
        float scaleWidth = Float.isNaN(motionKeyPosition.mPercentWidth) ? position2 : motionKeyPosition.mPercentWidth;
        float scaleHeight = Float.isNaN(motionKeyPosition.mPercentHeight) ? position2 : motionKeyPosition.mPercentHeight;
        float scaleX = motionPaths2.width - motionPaths.width;
        float scaleY = motionPaths2.height - motionPaths.height;
        this.position = this.time;
        float path = position2;
        float startCenterX = motionPaths.x + (motionPaths.width / 2.0f);
        float startCenterY = motionPaths.y + (motionPaths.height / 2.0f);
        float pathVectorX = (motionPaths2.x + (motionPaths2.width / 2.0f)) - startCenterX;
        float pathVectorY = (motionPaths2.y + (motionPaths2.height / 2.0f)) - startCenterY;
        this.x = (float) ((int) ((motionPaths.x + (pathVectorX * path)) - ((scaleX * scaleWidth) / 2.0f)));
        this.y = (float) ((int) ((motionPaths.y + (pathVectorY * path)) - ((scaleY * scaleHeight) / 2.0f)));
        this.width = (float) ((int) (motionPaths.width + (scaleX * scaleWidth)));
        this.height = (float) ((int) (motionPaths.height + (scaleY * scaleHeight)));
        float dxdx = Float.isNaN(motionKeyPosition.mPercentX) ? position2 : motionKeyPosition.mPercentX;
        float dxdy = 0.0f;
        float dydx = Float.isNaN(motionKeyPosition.mAltPercentY) ? 0.0f : motionKeyPosition.mAltPercentY;
        float dydy = Float.isNaN(motionKeyPosition.mPercentY) ? position2 : motionKeyPosition.mPercentY;
        if (!Float.isNaN(motionKeyPosition.mAltPercentX)) {
            dxdy = motionKeyPosition.mAltPercentX;
        }
        this.mMode = 0;
        this.x = (float) ((int) (((motionPaths.x + (pathVectorX * dxdx)) + (pathVectorY * dxdy)) - ((scaleX * scaleWidth) / 2.0f)));
        this.y = (float) ((int) (((motionPaths.y + (pathVectorX * dydx)) + (pathVectorY * dydy)) - ((scaleY * scaleHeight) / 2.0f)));
        this.mKeyFrameEasing = Easing.getInterpolator(motionKeyPosition.mTransitionEasing);
        this.mPathMotionArc = motionKeyPosition.mPathMotionArc;
    }

    public MotionPaths(int parentWidth, int parentHeight, MotionKeyPosition c, MotionPaths startTimePoint, MotionPaths endTimePoint) {
        if (startTimePoint.mAnimateRelativeTo != -1) {
            initPolar(parentWidth, parentHeight, c, startTimePoint, endTimePoint);
            return;
        }
        switch (c.mPositionType) {
            case 1:
                MotionPaths endTimePoint2 = endTimePoint;
                MotionPaths startTimePoint2 = startTimePoint;
                MotionKeyPosition c2 = c;
                int i = parentHeight;
                int parentHeight2 = parentWidth;
                initPath(c2, startTimePoint2, endTimePoint2);
                return;
            case 2:
                initScreen(parentWidth, parentHeight, c, startTimePoint, endTimePoint);
                MotionPaths motionPaths = endTimePoint;
                MotionPaths endTimePoint3 = startTimePoint;
                MotionKeyPosition motionKeyPosition = c;
                int i2 = parentHeight;
                int parentHeight3 = parentWidth;
                return;
            default:
                MotionPaths endTimePoint4 = endTimePoint;
                MotionPaths startTimePoint3 = startTimePoint;
                MotionKeyPosition c3 = c;
                int i3 = parentHeight;
                int parentHeight4 = parentWidth;
                initCartesian(c3, startTimePoint3, endTimePoint4);
                return;
        }
    }

    /* access modifiers changed from: package-private */
    public void initPolar(int parentWidth, int parentHeight, MotionKeyPosition c, MotionPaths s, MotionPaths e) {
        float f;
        float position2 = ((float) c.mFramePosition) / 100.0f;
        this.time = position2;
        this.mDrawPath = c.mDrawPath;
        this.mMode = c.mPositionType;
        float scaleWidth = Float.isNaN(c.mPercentWidth) ? position2 : c.mPercentWidth;
        float scaleHeight = Float.isNaN(c.mPercentHeight) ? position2 : c.mPercentHeight;
        float scaleX = e.width - s.width;
        float scaleY = e.height - s.height;
        this.position = this.time;
        this.width = (float) ((int) (s.width + (scaleX * scaleWidth)));
        this.height = (float) ((int) (s.height + (scaleY * scaleHeight)));
        float f2 = 1.0f - position2;
        float f3 = position2;
        switch (c.mPositionType) {
            case 1:
                this.x = ((Float.isNaN(c.mPercentX) ? position2 : c.mPercentX) * (e.x - s.x)) + s.x;
                this.y = ((Float.isNaN(c.mPercentY) ? position2 : c.mPercentY) * (e.y - s.y)) + s.y;
                break;
            case 2:
                this.x = Float.isNaN(c.mPercentX) ? ((e.x - s.x) * position2) + s.x : c.mPercentX * Math.min(scaleHeight, scaleWidth);
                this.y = Float.isNaN(c.mPercentY) ? ((e.y - s.y) * position2) + s.y : c.mPercentY;
                break;
            default:
                if (Float.isNaN(c.mPercentX)) {
                    f = position2;
                } else {
                    f = c.mPercentX;
                }
                this.x = (f * (e.x - s.x)) + s.x;
                this.y = ((Float.isNaN(c.mPercentY) ? position2 : c.mPercentY) * (e.y - s.y)) + s.y;
                break;
        }
        this.mAnimateRelativeTo = s.mAnimateRelativeTo;
        this.mKeyFrameEasing = Easing.getInterpolator(c.mTransitionEasing);
        this.mPathMotionArc = c.mPathMotionArc;
    }

    public void setupRelative(Motion mc, MotionPaths relative) {
        double dx = (double) (((this.x + (this.width / 2.0f)) - relative.x) - (relative.width / 2.0f));
        double dy = (double) (((this.y + (this.height / 2.0f)) - relative.y) - (relative.height / 2.0f));
        this.mRelativeToController = mc;
        this.x = (float) Math.hypot(dy, dx);
        if (Float.isNaN(this.mRelativeAngle)) {
            this.y = (float) (Math.atan2(dy, dx) + 1.5707963267948966d);
        } else {
            this.y = (float) Math.toRadians((double) this.mRelativeAngle);
        }
    }

    /* access modifiers changed from: package-private */
    public void initScreen(int parentWidth, int parentHeight, MotionKeyPosition c, MotionPaths startTimePoint, MotionPaths endTimePoint) {
        int parentWidth2;
        MotionKeyPosition motionKeyPosition = c;
        MotionPaths motionPaths = startTimePoint;
        MotionPaths motionPaths2 = endTimePoint;
        float position2 = ((float) motionKeyPosition.mFramePosition) / 100.0f;
        this.time = position2;
        this.mDrawPath = motionKeyPosition.mDrawPath;
        float scaleWidth = Float.isNaN(motionKeyPosition.mPercentWidth) ? position2 : motionKeyPosition.mPercentWidth;
        float scaleHeight = Float.isNaN(motionKeyPosition.mPercentHeight) ? position2 : motionKeyPosition.mPercentHeight;
        float scaleX = motionPaths2.width - motionPaths.width;
        float scaleY = motionPaths2.height - motionPaths.height;
        this.position = this.time;
        float path = position2;
        float startCenterX = motionPaths.x + (motionPaths.width / 2.0f);
        float startCenterY = motionPaths.y + (motionPaths.height / 2.0f);
        float endCenterX = motionPaths2.x + (motionPaths2.width / 2.0f);
        float endCenterY = motionPaths2.y + (motionPaths2.height / 2.0f);
        this.x = (float) ((int) ((motionPaths.x + ((endCenterX - startCenterX) * path)) - ((scaleX * scaleWidth) / 2.0f)));
        this.y = (float) ((int) ((motionPaths.y + ((endCenterY - startCenterY) * path)) - ((scaleY * scaleHeight) / 2.0f)));
        this.width = (float) ((int) (motionPaths.width + (scaleX * scaleWidth)));
        this.height = (float) ((int) (motionPaths.height + (scaleY * scaleHeight)));
        this.mMode = 2;
        if (!Float.isNaN(motionKeyPosition.mPercentX)) {
            parentWidth2 = (int) (((float) parentWidth) - this.width);
            this.x = (float) ((int) (((float) parentWidth2) * motionKeyPosition.mPercentX));
        } else {
            parentWidth2 = parentWidth;
        }
        if (!Float.isNaN(motionKeyPosition.mPercentY)) {
            int i = parentWidth2;
            this.y = (float) ((int) (((float) ((int) (((float) parentHeight) - this.height))) * motionKeyPosition.mPercentY));
        } else {
            int i2 = parentWidth2;
            int parentWidth3 = parentHeight;
        }
        this.mAnimateRelativeTo = this.mAnimateRelativeTo;
        this.mKeyFrameEasing = Easing.getInterpolator(motionKeyPosition.mTransitionEasing);
        this.mPathMotionArc = motionKeyPosition.mPathMotionArc;
    }

    /* access modifiers changed from: package-private */
    public void initPath(MotionKeyPosition c, MotionPaths startTimePoint, MotionPaths endTimePoint) {
        MotionKeyPosition motionKeyPosition = c;
        MotionPaths motionPaths = startTimePoint;
        MotionPaths motionPaths2 = endTimePoint;
        float position2 = ((float) motionKeyPosition.mFramePosition) / 100.0f;
        this.time = position2;
        this.mDrawPath = motionKeyPosition.mDrawPath;
        float scaleWidth = Float.isNaN(motionKeyPosition.mPercentWidth) ? position2 : motionKeyPosition.mPercentWidth;
        float scaleHeight = Float.isNaN(motionKeyPosition.mPercentHeight) ? position2 : motionKeyPosition.mPercentHeight;
        float scaleX = motionPaths2.width - motionPaths.width;
        float scaleY = motionPaths2.height - motionPaths.height;
        this.position = this.time;
        float path = Float.isNaN(motionKeyPosition.mPercentX) ? position2 : motionKeyPosition.mPercentX;
        float startCenterX = motionPaths.x + (motionPaths.width / 2.0f);
        float startCenterY = motionPaths.y + (motionPaths.height / 2.0f);
        float pathVectorX = (motionPaths2.x + (motionPaths2.width / 2.0f)) - startCenterX;
        float pathVectorY = (motionPaths2.y + (motionPaths2.height / 2.0f)) - startCenterY;
        float f = position2;
        this.x = (float) ((int) ((motionPaths.x + (pathVectorX * path)) - ((scaleX * scaleWidth) / 2.0f)));
        this.y = (float) ((int) ((motionPaths.y + (pathVectorY * path)) - ((scaleY * scaleHeight) / 2.0f)));
        this.width = (float) ((int) (motionPaths.width + (scaleX * scaleWidth)));
        this.height = (float) ((int) (motionPaths.height + (scaleY * scaleHeight)));
        float perpendicular = Float.isNaN(motionKeyPosition.mPercentY) ? 0.0f : motionKeyPosition.mPercentY;
        this.mMode = 1;
        this.x = (float) ((int) ((motionPaths.x + (pathVectorX * path)) - ((scaleX * scaleWidth) / 2.0f)));
        this.y = (float) ((int) ((motionPaths.y + (pathVectorY * path)) - ((scaleY * scaleHeight) / 2.0f)));
        this.x += (-pathVectorY) * perpendicular;
        this.y += pathVectorX * perpendicular;
        this.mAnimateRelativeTo = this.mAnimateRelativeTo;
        this.mKeyFrameEasing = Easing.getInterpolator(motionKeyPosition.mTransitionEasing);
        this.mPathMotionArc = motionKeyPosition.mPathMotionArc;
    }

    private static final float xRotate(float sin, float cos, float cx, float cy, float x2, float y2) {
        return (((x2 - cx) * cos) - ((y2 - cy) * sin)) + cx;
    }

    private static final float yRotate(float sin, float cos, float cx, float cy, float x2, float y2) {
        return ((x2 - cx) * sin) + ((y2 - cy) * cos) + cy;
    }

    private boolean diff(float a, float b) {
        if (Float.isNaN(a) || Float.isNaN(b)) {
            if (Float.isNaN(a) != Float.isNaN(b)) {
                return true;
            }
            return false;
        } else if (Math.abs(a - b) > 1.0E-6f) {
            return true;
        } else {
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public void different(MotionPaths points, boolean[] mask, String[] custom, boolean arcMode) {
        boolean diffx = diff(this.x, points.x);
        boolean diffy = diff(this.y, points.y);
        int c = 0 + 1;
        mask[0] = mask[0] | diff(this.position, points.position);
        int c2 = c + 1;
        mask[c] = mask[c] | diffx | diffy | arcMode;
        int c3 = c2 + 1;
        mask[c2] = mask[c2] | diffx | diffy | arcMode;
        int c4 = c3 + 1;
        mask[c3] = mask[c3] | diff(this.width, points.width);
        int i = c4 + 1;
        mask[c4] = mask[c4] | diff(this.height, points.height);
    }

    /* access modifiers changed from: package-private */
    public void getCenter(double p, int[] toUse, double[] data, float[] point, int offset) {
        float f;
        int[] iArr = toUse;
        float v_x = this.x;
        float v_y = this.y;
        float v_width = this.width;
        float v_height = this.height;
        for (int i = 0; i < iArr.length; i++) {
            float value = (float) data[i];
            switch (iArr[i]) {
                case 1:
                    v_x = value;
                    break;
                case 2:
                    v_y = value;
                    break;
                case 3:
                    v_width = value;
                    break;
                case 4:
                    v_height = value;
                    break;
            }
        }
        if (this.mRelativeToController != null) {
            float[] pos = new float[2];
            this.mRelativeToController.getCenter(p, pos, new float[2]);
            float rx = pos[0];
            float ry = pos[1];
            float radius = v_x;
            float[] fArr = pos;
            f = 2.0f;
            float angle = v_y;
            float angle2 = v_x;
            float v_x2 = (float) ((((double) rx) + (Math.sin((double) angle) * ((double) radius))) - ((double) (v_width / 2.0f)));
            v_y = (float) ((((double) ry) - (Math.cos((double) angle) * ((double) radius))) - ((double) (v_height / 2.0f)));
            v_x = v_x2;
        } else {
            double d = p;
            float f2 = v_x;
            f = 2.0f;
        }
        point[offset] = (v_width / f) + v_x + 0.0f;
        point[offset + 1] = (v_height / f) + v_y + 0.0f;
    }

    /* access modifiers changed from: package-private */
    public void getCenter(double p, int[] toUse, double[] data, float[] point, double[] vdata, float[] velocity) {
        float v_width;
        float v_height;
        float f;
        int[] iArr = toUse;
        float v_x = this.x;
        float v_y = this.y;
        float v_width2 = this.width;
        float v_height2 = this.height;
        float dv_x = 0.0f;
        float dv_y = 0.0f;
        float dv_width = 0.0f;
        float dv_height = 0.0f;
        for (int i = 0; i < iArr.length; i++) {
            float value = (float) data[i];
            float dvalue = (float) vdata[i];
            switch (iArr[i]) {
                case 1:
                    v_x = value;
                    dv_x = dvalue;
                    break;
                case 2:
                    v_y = value;
                    dv_y = dvalue;
                    break;
                case 3:
                    v_width2 = value;
                    dv_width = dvalue;
                    break;
                case 4:
                    v_height2 = value;
                    dv_height = dvalue;
                    break;
            }
        }
        float dpos_x = (dv_width / 2.0f) + dv_x;
        float dpos_y = (dv_height / 2.0f) + dv_y;
        if (this.mRelativeToController != null) {
            f = 2.0f;
            float[] pos = new float[2];
            float[] vel = new float[2];
            float v_x2 = v_x;
            this.mRelativeToController.getCenter(p, pos, vel);
            float rx = pos[0];
            float ry = pos[1];
            float drx = vel[0];
            float dry = vel[1];
            v_width = v_width2;
            v_height = v_height2;
            float f2 = rx;
            double d = (double) rx;
            float radius = v_x2;
            float f3 = dv_x;
            float angle = v_y;
            float v_x3 = (float) ((d + (Math.sin((double) angle) * ((double) radius))) - ((double) (v_width / 2.0f)));
            float f4 = ry;
            float f5 = radius;
            float v_y2 = (float) ((((double) ry) - (((double) radius) * Math.cos((double) angle))) - ((double) (v_height / 2.0f)));
            float dradius = dv_x;
            float v_y3 = v_y2;
            float dangle = dv_y;
            dpos_x = (float) (((double) drx) + (Math.sin((double) angle) * ((double) dradius)) + (((double) dangle) * Math.cos((double) angle)));
            float f6 = drx;
            float f7 = dry;
            float f8 = dradius;
            dpos_y = (float) ((((double) dry) - (((double) dradius) * Math.cos((double) angle))) + (((double) dangle) * Math.sin((double) angle)));
            v_x = v_x3;
            v_y = v_y3;
        } else {
            float f9 = v_y;
            v_width = v_width2;
            v_height = v_height2;
            float f10 = dv_x;
            f = 2.0f;
        }
        point[0] = (v_width / f) + v_x + 0.0f;
        point[1] = (v_height / f) + v_y + 0.0f;
        velocity[0] = dpos_x;
        velocity[1] = dpos_y;
    }

    /* access modifiers changed from: package-private */
    public void getCenterVelocity(double p, int[] toUse, double[] data, float[] point, int offset) {
        float f;
        int[] iArr = toUse;
        float v_x = this.x;
        float v_y = this.y;
        float v_width = this.width;
        float v_height = this.height;
        for (int i = 0; i < iArr.length; i++) {
            float value = (float) data[i];
            switch (iArr[i]) {
                case 1:
                    v_x = value;
                    break;
                case 2:
                    v_y = value;
                    break;
                case 3:
                    v_width = value;
                    break;
                case 4:
                    v_height = value;
                    break;
            }
        }
        if (this.mRelativeToController != null) {
            float[] pos = new float[2];
            this.mRelativeToController.getCenter(p, pos, new float[2]);
            float rx = pos[0];
            float ry = pos[1];
            float radius = v_x;
            float[] fArr = pos;
            f = 2.0f;
            float angle = v_y;
            float angle2 = v_x;
            float v_x2 = (float) ((((double) rx) + (Math.sin((double) angle) * ((double) radius))) - ((double) (v_width / 2.0f)));
            v_y = (float) ((((double) ry) - (Math.cos((double) angle) * ((double) radius))) - ((double) (v_height / 2.0f)));
            v_x = v_x2;
        } else {
            double d = p;
            float f2 = v_x;
            f = 2.0f;
        }
        point[offset] = (v_width / f) + v_x + 0.0f;
        point[offset + 1] = (v_height / f) + v_y + 0.0f;
    }

    /* access modifiers changed from: package-private */
    public void getBounds(int[] toUse, double[] data, float[] point, int offset) {
        float f = this.x;
        float f2 = this.y;
        float v_width = this.width;
        float v_height = this.height;
        for (int i = 0; i < toUse.length; i++) {
            float value = (float) data[i];
            switch (toUse[i]) {
                case 1:
                    float v_x = value;
                    break;
                case 2:
                    float v_y = value;
                    break;
                case 3:
                    v_width = value;
                    break;
                case 4:
                    v_height = value;
                    break;
            }
        }
        point[offset] = v_width;
        point[offset + 1] = v_height;
    }

    /* access modifiers changed from: package-private */
    public void setView(float position2, MotionWidget view, int[] toUse, double[] data, double[] slope, double[] cycle) {
        char c;
        float v_width;
        float v_height;
        float dv_x;
        int i;
        float v_y;
        double d;
        MotionWidget motionWidget = view;
        int[] iArr = toUse;
        double[] dArr = slope;
        float v_x = this.x;
        float v_y2 = this.y;
        float dv_width = this.width;
        float dv_height = this.height;
        float dv_x2 = 0.0f;
        float dv_y = 0.0f;
        float dv_width2 = 0.0f;
        float dv_height2 = 0.0f;
        float path_rotate = Float.NaN;
        if (iArr.length != 0) {
            c = 1;
            if (this.mTempValue.length <= iArr[iArr.length - 1]) {
                int scratch_data_length = iArr[iArr.length - 1] + 1;
                this.mTempValue = new double[scratch_data_length];
                this.mTempDelta = new double[scratch_data_length];
            }
        } else {
            c = 1;
        }
        float v_x2 = v_x;
        float v_y3 = v_y2;
        Arrays.fill(this.mTempValue, Double.NaN);
        for (int i2 = 0; i2 < iArr.length; i2++) {
            this.mTempValue[iArr[i2]] = data[i2];
            this.mTempDelta[iArr[i2]] = dArr[i2];
        }
        int i3 = 0;
        float v_y4 = v_y3;
        while (i3 < this.mTempValue.length) {
            double deltaCycle = 0.0d;
            if (Double.isNaN(this.mTempValue[i3])) {
                if (cycle == null) {
                    i = i3;
                    v_y = v_y4;
                } else if (cycle[i3] == 0.0d) {
                    i = i3;
                    v_y = v_y4;
                }
                v_y4 = v_y;
                i3 = i + 1;
            }
            if (cycle != null) {
                deltaCycle = cycle[i3];
            }
            if (Double.isNaN(this.mTempValue[i3])) {
                i = i3;
                v_y = v_y4;
                d = deltaCycle;
            } else {
                i = i3;
                v_y = v_y4;
                d = this.mTempValue[i3] + deltaCycle;
            }
            float value = (float) d;
            float dvalue = (float) this.mTempDelta[i];
            switch (i) {
                case 0:
                    float delta_path = value;
                    v_y4 = v_y;
                    continue;
                case 1:
                    dv_x2 = dvalue;
                    v_x2 = value;
                    v_y4 = v_y;
                    continue;
                case 2:
                    v_y4 = value;
                    dv_y = dvalue;
                    continue;
                case 3:
                    dv_width2 = dvalue;
                    dv_width = value;
                    v_y4 = v_y;
                    continue;
                case 4:
                    dv_height2 = dvalue;
                    dv_height = value;
                    v_y4 = v_y;
                    continue;
                case 5:
                    path_rotate = value;
                    v_y4 = v_y;
                    continue;
            }
            v_y4 = v_y;
            i3 = i + 1;
        }
        int i4 = i3;
        float v_y5 = v_y4;
        if (this.mRelativeToController != null) {
            float[] pos = new float[2];
            float[] vel = new float[2];
            v_width = dv_width;
            v_height = dv_height;
            this.mRelativeToController.getCenter((double) position2, pos, vel);
            float rx = pos[0];
            float ry = pos[c];
            float dangle = dv_y;
            float drx = vel[0];
            float dry = vel[c];
            float f = dv_x2;
            float f2 = dv_y;
            float f3 = rx;
            float radius = v_x2;
            float[] fArr = vel;
            float angle = v_y5;
            float pos_x = (float) ((((double) rx) + (Math.sin((double) angle) * ((double) radius))) - ((double) (v_width / 2.0f)));
            float f4 = ry;
            float pos_y = (float) ((((double) ry) - (Math.cos((double) angle) * ((double) radius))) - ((double) (v_height / 2.0f)));
            float dradius = dv_x2;
            float dangle2 = dangle;
            float dpos_x = (float) (((double) drx) + (Math.sin((double) angle) * ((double) dradius)) + (((double) dangle2) * Math.cos((double) angle) * ((double) radius)));
            float f5 = dv_width2;
            float dv_height3 = dv_height2;
            float f6 = dradius;
            double sin = Math.sin((double) angle) * ((double) radius);
            float f7 = drx;
            float f8 = angle;
            float dpos_y = (float) ((((double) dry) - (((double) dradius) * Math.cos((double) angle))) + (sin * ((double) dangle2)));
            float dv_x3 = dpos_x;
            float dv_y2 = dpos_y;
            v_x2 = pos_x;
            float v_y6 = pos_y;
            float f9 = dry;
            float f10 = radius;
            if (dArr.length >= 2) {
                slope[0] = (double) dpos_x;
                slope[c] = (double) dpos_y;
            }
            if (!Float.isNaN(path_rotate)) {
                float f11 = dpos_x;
                float f12 = dv_height3;
                motionWidget.setRotationZ((float) (((double) path_rotate) + Math.toDegrees(Math.atan2((double) dv_y2, (double) dv_x3))));
            } else {
                float f13 = dv_height3;
            }
            float dangle3 = dv_x3;
            dv_x = v_y6;
        } else {
            v_width = dv_width;
            v_height = dv_height;
            float dv_x4 = dv_x2;
            float dv_y3 = dv_y;
            float dv_width3 = dv_width2;
            float dv_height4 = dv_height2;
            if (!Float.isNaN(path_rotate)) {
                motionWidget.setRotationZ((float) (((double) 0.0f) + ((double) path_rotate) + Math.toDegrees(Math.atan2((double) (dv_y3 + (dv_height4 / 2.0f)), (double) (dv_x4 + (dv_width3 / 2.0f))))));
            }
            dv_x = v_y5;
            float f14 = dv_y3;
            float f15 = dv_x4;
        }
        int l = (int) (v_x2 + 0.5f);
        int t = (int) (dv_x + 0.5f);
        int r = (int) (v_x2 + 0.5f + v_width);
        int b = (int) (0.5f + dv_x + v_height);
        int i5 = r - l;
        int i6 = b - t;
        motionWidget.layout(l, t, r, b);
    }

    /* access modifiers changed from: package-private */
    public void getRect(int[] toUse, double[] data, float[] path, int offset) {
        float ry;
        float f;
        float v_height;
        float angle;
        float v_x;
        float cx;
        float cy;
        float x1;
        float y1;
        float y4;
        float x4;
        int[] iArr = toUse;
        float v_x2 = this.x;
        float v_y = this.y;
        float v_width = this.width;
        float v_height2 = this.height;
        float v_x3 = v_x2;
        int i = 0;
        while (true) {
            float v_y2 = v_y;
            if (i < iArr.length) {
                int i2 = i;
                float value = (float) data[i2];
                switch (toUse[i2]) {
                    case 0:
                        float delta_path = value;
                        break;
                    case 1:
                        v_x3 = value;
                        break;
                    case 2:
                        v_y2 = value;
                        break;
                    case 3:
                        v_width = value;
                        break;
                    case 4:
                        v_height2 = value;
                        break;
                }
                i = i2 + 1;
                iArr = toUse;
                v_y = v_y2;
            } else {
                int i3 = i;
                if (this.mRelativeToController != null) {
                    float rx = this.mRelativeToController.getCenterX();
                    float ry2 = this.mRelativeToController.getCenterY();
                    f = 2.0f;
                    float radius = v_x3;
                    float radius2 = rx;
                    float angle2 = v_y2;
                    float v_x4 = (float) ((((double) rx) + (Math.sin((double) angle2) * ((double) radius))) - ((double) (v_width / 2.0f)));
                    v_height = v_height2;
                    float ry3 = ry2;
                    ry = v_width;
                    float f2 = ry3;
                    float f3 = radius;
                    angle = (float) ((((double) ry3) - (((double) radius) * Math.cos((double) angle2))) - ((double) (v_height / 2.0f)));
                    v_x = v_x4;
                } else {
                    ry = v_width;
                    v_height = v_height2;
                    f = 2.0f;
                    angle = v_y2;
                    v_x = v_x3;
                }
                float x12 = v_x;
                float y12 = angle;
                float x2 = v_x + ry;
                float y2 = y12;
                float x3 = x2;
                float y3 = angle + v_height;
                float x42 = x12;
                float y42 = y3;
                float cx2 = x12 + (ry / f);
                float cy2 = y12 + (v_height / f);
                if (!Float.isNaN(Float.NaN)) {
                    cx = x12 + ((x2 - x12) * Float.NaN);
                } else {
                    cx = cx2;
                }
                if (!Float.isNaN(Float.NaN)) {
                    cy = y12 + ((y3 - y12) * Float.NaN);
                } else {
                    cy = cy2;
                }
                if (1.0f != 1.0f) {
                    float midx = (x12 + x2) / f;
                    x2 = ((x2 - midx) * 1.0f) + midx;
                    x3 = ((x3 - midx) * 1.0f) + midx;
                    x42 = ((x42 - midx) * 1.0f) + midx;
                    x1 = ((x12 - midx) * 1.0f) + midx;
                } else {
                    x1 = x12;
                }
                if (1.0f != 1.0f) {
                    float midy = (y12 + y3) / f;
                    y2 = ((y2 - midy) * 1.0f) + midy;
                    y3 = ((y3 - midy) * 1.0f) + midy;
                    y42 = ((y42 - midy) * 1.0f) + midy;
                    y1 = ((y12 - midy) * 1.0f) + midy;
                } else {
                    y1 = y12;
                }
                if (0.0f != 0.0f) {
                    float sin = (float) Math.sin(Math.toRadians((double) 0.0f));
                    float cos = (float) Math.cos(Math.toRadians((double) 0.0f));
                    float cos2 = xRotate(sin, cos, cx, cy, x1, y1);
                    float ty1 = yRotate(sin, cos, cx, cy, x1, y1);
                    float f4 = x1;
                    float f5 = y1;
                    float x13 = x2;
                    float y22 = y2;
                    x2 = xRotate(sin, cos, cx, cy, x13, y22);
                    y2 = yRotate(sin, cos, cx, cy, x13, y22);
                    float f6 = x13;
                    float f7 = y22;
                    float x22 = x3;
                    float y32 = y3;
                    x3 = xRotate(sin, cos, cx, cy, x22, y32);
                    y3 = yRotate(sin, cos, cx, cy, x22, y32);
                    float f8 = x22;
                    float f9 = y32;
                    float x43 = x42;
                    float y43 = y42;
                    x42 = xRotate(sin, cos, cx, cy, x43, y43);
                    y42 = yRotate(sin, cos, cx, cy, x43, y43);
                    x4 = cos2;
                    y4 = ty1;
                } else {
                    float f10 = y2;
                    float f11 = x3;
                    float f12 = y3;
                    float x14 = x1;
                    float y13 = y1;
                    float x15 = x42;
                    float y14 = y42;
                    x4 = x14;
                    y4 = y13;
                }
                int offset2 = offset + 1;
                path[offset] = x4 + 0.0f;
                int offset3 = offset2 + 1;
                path[offset2] = y4 + 0.0f;
                int offset4 = offset3 + 1;
                path[offset3] = x2 + 0.0f;
                int offset5 = offset4 + 1;
                path[offset4] = y2 + 0.0f;
                int offset6 = offset5 + 1;
                path[offset5] = x3 + 0.0f;
                int offset7 = offset6 + 1;
                path[offset6] = y3 + 0.0f;
                int offset8 = offset7 + 1;
                path[offset7] = x42 + 0.0f;
                int i4 = offset8 + 1;
                path[offset8] = y42 + 0.0f;
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void setDpDt(float locationX, float locationY, float[] mAnchorDpDt, int[] toUse, double[] deltaData, double[] data) {
        int[] iArr = toUse;
        float d_x = 0.0f;
        float d_y = 0.0f;
        float d_width = 0.0f;
        float d_height = 0.0f;
        for (int i = 0; i < iArr.length; i++) {
            float deltaV = (float) deltaData[i];
            float f = (float) data[i];
            switch (iArr[i]) {
                case 1:
                    d_x = deltaV;
                    break;
                case 2:
                    d_y = deltaV;
                    break;
                case 3:
                    d_width = deltaV;
                    break;
                case 4:
                    d_height = deltaV;
                    break;
            }
        }
        float deltaX = d_x - ((0.0f * d_width) / 2.0f);
        float deltaY = d_y - ((0.0f * d_height) / 2.0f);
        mAnchorDpDt[0] = ((1.0f - locationX) * deltaX) + ((deltaX + ((0.0f + 1.0f) * d_width)) * locationX) + 0.0f;
        mAnchorDpDt[1] = ((1.0f - locationY) * deltaY) + ((deltaY + ((0.0f + 1.0f) * d_height)) * locationY) + 0.0f;
    }

    /* access modifiers changed from: package-private */
    public void fillStandard(double[] data, int[] toUse) {
        float[] set = {this.position, this.x, this.y, this.width, this.height, this.mPathRotate};
        int c = 0;
        for (int i = 0; i < toUse.length; i++) {
            if (toUse[i] < set.length) {
                data[c] = (double) set[toUse[i]];
                c++;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean hasCustomData(String name) {
        return this.customAttributes.containsKey(name);
    }

    /* access modifiers changed from: package-private */
    public int getCustomDataCount(String name) {
        CustomVariable a = this.customAttributes.get(name);
        if (a == null) {
            return 0;
        }
        return a.numberOfInterpolatedValues();
    }

    /* access modifiers changed from: package-private */
    public int getCustomData(String name, double[] value, int offset) {
        CustomVariable a = this.customAttributes.get(name);
        if (a == null) {
            return 0;
        }
        if (a.numberOfInterpolatedValues() == 1) {
            value[offset] = (double) a.getValueToInterpolate();
            return 1;
        }
        int N = a.numberOfInterpolatedValues();
        float[] f = new float[N];
        a.getValuesToInterpolate(f);
        int i = 0;
        while (i < N) {
            value[offset] = (double) f[i];
            i++;
            offset++;
        }
        return N;
    }

    /* access modifiers changed from: package-private */
    public void setBounds(float x2, float y2, float w, float h) {
        this.x = x2;
        this.y = y2;
        this.width = w;
        this.height = h;
    }

    public int compareTo(MotionPaths o) {
        return Float.compare(this.position, o.position);
    }

    public void applyParameters(MotionWidget c) {
        this.mKeyFrameEasing = Easing.getInterpolator(c.motion.mTransitionEasing);
        this.mPathMotionArc = c.motion.mPathMotionArc;
        this.mAnimateRelativeTo = c.motion.mAnimateRelativeTo;
        this.mPathRotate = c.motion.mPathRotate;
        this.mDrawPath = c.motion.mDrawPath;
        this.mAnimateCircleAngleTo = c.motion.mAnimateCircleAngleTo;
        this.mProgress = c.propertySet.mProgress;
        this.mRelativeAngle = 0.0f;
        for (String s : c.getCustomAttributeNames()) {
            CustomVariable attr = c.getCustomAttribute(s);
            if (attr != null && attr.isContinuous()) {
                this.customAttributes.put(s, attr);
            }
        }
    }

    public void configureRelativeTo(Motion toOrbit) {
        double[] pos = toOrbit.getPos((double) this.mProgress);
    }
}
