package androidx.constraintlayout.core.parser;

import androidx.constraintlayout.widget.ConstraintLayout;

public class CLParser {
    static boolean DEBUG = false;
    private boolean hasComment = false;
    private int lineNumber;
    private String mContent;

    enum TYPE {
        UNKNOWN,
        OBJECT,
        ARRAY,
        NUMBER,
        STRING,
        KEY,
        TOKEN
    }

    public static CLObject parse(String string) throws CLParsingException {
        return new CLParser(string).parse();
    }

    public CLParser(String content) {
        this.mContent = content;
    }

    public CLObject parse() throws CLParsingException {
        int i;
        int startIndex;
        char ck;
        char[] content = this.mContent.toCharArray();
        int length = content.length;
        int i2 = 1;
        this.lineNumber = 1;
        int startIndex2 = -1;
        int i3 = 0;
        while (true) {
            if (i3 >= length) {
                break;
            }
            char c = content[i3];
            if (c == '{') {
                startIndex2 = i3;
                break;
            }
            if (c == 10) {
                this.lineNumber++;
            }
            i3++;
        }
        if (startIndex2 != -1) {
            CLObject root = CLObject.allocate(content);
            root.setLine(this.lineNumber);
            root.setStart((long) startIndex2);
            CLElement currentElement = root;
            int i4 = startIndex2 + 1;
            while (true) {
                if (i4 >= length) {
                    i = 1;
                    break;
                }
                char c2 = content[i4];
                if (c2 == 10) {
                    this.lineNumber += i2;
                }
                if (this.hasComment) {
                    if (c2 == 10) {
                        this.hasComment = false;
                    } else {
                        startIndex = startIndex2;
                        i4++;
                        startIndex2 = startIndex;
                        i2 = 1;
                    }
                }
                if (currentElement == null) {
                    int i5 = startIndex2;
                    i = 1;
                    break;
                }
                if (currentElement.isDone()) {
                    currentElement = getNextJsonElement(i4, c2, currentElement, content);
                    startIndex = startIndex2;
                } else if (currentElement instanceof CLObject) {
                    if (c2 == '}') {
                        currentElement.setEnd((long) (i4 - 1));
                        startIndex = startIndex2;
                    } else {
                        currentElement = getNextJsonElement(i4, c2, currentElement, content);
                        startIndex = startIndex2;
                    }
                } else if (currentElement instanceof CLArray) {
                    if (c2 == ']') {
                        currentElement.setEnd((long) (i4 - 1));
                        startIndex = startIndex2;
                    } else {
                        currentElement = getNextJsonElement(i4, c2, currentElement, content);
                        startIndex = startIndex2;
                    }
                } else if (currentElement instanceof CLString) {
                    if (content[(int) currentElement.start] == c2) {
                        currentElement.setStart(currentElement.start + 1);
                        currentElement.setEnd((long) (i4 - 1));
                    }
                    startIndex = startIndex2;
                } else {
                    if (currentElement instanceof CLToken) {
                        CLToken token = (CLToken) currentElement;
                        startIndex = startIndex2;
                        if (!token.validate(c2, (long) i4)) {
                            throw new CLParsingException("parsing incorrect token " + token.content() + " at line " + this.lineNumber, token);
                        }
                    } else {
                        startIndex = startIndex2;
                    }
                    if (((currentElement instanceof CLKey) || (currentElement instanceof CLString)) && (((ck = content[(int) currentElement.start]) == '\'' || ck == '\"') && ck == c2)) {
                        currentElement.setStart(currentElement.start + 1);
                        currentElement.setEnd((long) (i4 - 1));
                    }
                    if (currentElement.isDone() == 0 && (c2 == '}' || c2 == ']' || c2 == ',' || c2 == ' ' || c2 == 9 || c2 == 13 || c2 == 10 || c2 == ':')) {
                        currentElement.setEnd((long) (i4 - 1));
                        if (c2 == '}' || c2 == ']') {
                            currentElement = currentElement.getContainer();
                            currentElement.setEnd((long) (i4 - 1));
                            if (currentElement instanceof CLKey) {
                                currentElement = currentElement.getContainer();
                                currentElement.setEnd((long) (i4 - 1));
                            }
                        }
                    }
                }
                if (currentElement.isDone() && (!(currentElement instanceof CLKey) || ((CLKey) currentElement).mElements.size() > 0)) {
                    currentElement = currentElement.getContainer();
                }
                i4++;
                startIndex2 = startIndex;
                i2 = 1;
            }
            while (currentElement != null && !currentElement.isDone()) {
                if (currentElement instanceof CLString) {
                    currentElement.setStart((long) (((int) currentElement.start) + i));
                }
                currentElement.setEnd((long) (length - 1));
                currentElement = currentElement.getContainer();
            }
            if (DEBUG) {
                System.out.println("Root: " + root.toJSON());
            }
            return root;
        }
        throw new CLParsingException("invalid json content", (CLElement) null);
    }

    private CLElement getNextJsonElement(int position, char c, CLElement currentElement, char[] content) throws CLParsingException {
        CLElement currentElement2;
        switch (c) {
            case 9:
            case 10:
            case 13:
            case ' ':
            case ',':
            case ':':
                currentElement2 = currentElement;
                char[] cArr = content;
                break;
            case '\"':
            case '\'':
                int position2 = position;
                CLElement currentElement3 = currentElement;
                char[] content2 = content;
                if ((currentElement3 instanceof CLObject) != 0) {
                    return createElement(currentElement3, position2, TYPE.KEY, true, content2);
                }
                return createElement(currentElement3, position2, TYPE.STRING, true, content2);
            case '+':
            case '-':
            case '.':
            case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE /*48*/:
            case ConstraintLayout.LayoutParams.Table.LAYOUT_EDITOR_ABSOLUTEX /*49*/:
            case '2':
            case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_TAG /*51*/:
            case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_BASELINE_TO_TOP_OF /*52*/:
            case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_BASELINE_TO_BOTTOM_OF /*53*/:
            case ConstraintLayout.LayoutParams.Table.LAYOUT_MARGIN_BASELINE /*54*/:
            case ConstraintLayout.LayoutParams.Table.LAYOUT_GONE_MARGIN_BASELINE /*55*/:
            case '8':
            case '9':
                return createElement(currentElement, position, TYPE.NUMBER, true, content);
            case '/':
                int position3 = position;
                currentElement2 = currentElement;
                char[] content3 = content;
                if (position3 + 1 < content3.length && content3[position3 + 1] == '/') {
                    this.hasComment = true;
                    break;
                }
            case '[':
                return createElement(currentElement, position, TYPE.ARRAY, true, content);
            case ']':
            case '}':
                int position4 = position;
                CLElement currentElement4 = currentElement;
                char[] cArr2 = content;
                currentElement4.setEnd((long) (position4 - 1));
                CLElement currentElement5 = currentElement4.getContainer();
                currentElement5.setEnd((long) position4);
                return currentElement5;
            case '{':
                return createElement(currentElement, position, TYPE.OBJECT, true, content);
            default:
                int position5 = position;
                CLElement currentElement6 = currentElement;
                char[] content4 = content;
                if ((currentElement6 instanceof CLContainer) == 0 || (currentElement6 instanceof CLObject)) {
                    return createElement(currentElement6, position5, TYPE.KEY, true, content4);
                }
                CLElement currentElement7 = createElement(currentElement6, position5, TYPE.TOKEN, true, content4);
                CLToken token = (CLToken) currentElement7;
                if (token.validate(c, (long) position5)) {
                    return currentElement7;
                }
                throw new CLParsingException("incorrect token <" + c + "> at line " + this.lineNumber, token);
        }
        return currentElement2;
    }

    private CLElement createElement(CLElement currentElement, int position, TYPE type, boolean applyStart, char[] content) {
        CLElement newElement = null;
        if (DEBUG) {
            System.out.println("CREATE " + type + " at " + content[position]);
        }
        switch (type) {
            case OBJECT:
                newElement = CLObject.allocate(content);
                position++;
                break;
            case ARRAY:
                newElement = CLArray.allocate(content);
                position++;
                break;
            case STRING:
                newElement = CLString.allocate(content);
                break;
            case NUMBER:
                newElement = CLNumber.allocate(content);
                break;
            case KEY:
                newElement = CLKey.allocate(content);
                break;
            case TOKEN:
                newElement = CLToken.allocate(content);
                break;
        }
        if (newElement == null) {
            return null;
        }
        newElement.setLine(this.lineNumber);
        if (applyStart) {
            newElement.setStart((long) position);
        }
        if (currentElement instanceof CLContainer) {
            newElement.setContainer((CLContainer) currentElement);
        }
        return newElement;
    }
}
