package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import java.util.HashMap;

public class Barrier extends HelperWidget {
    public static final int BOTTOM = 3;
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    public static final int TOP = 2;
    private static final boolean USE_RELAX_GONE = false;
    private static final boolean USE_RESOLUTION = true;
    private boolean mAllowsGoneWidget = true;
    private int mBarrierType = 0;
    private int mMargin = 0;
    boolean resolved = false;

    public Barrier() {
    }

    public Barrier(String debugName) {
        setDebugName(debugName);
    }

    public boolean allowedInBarrier() {
        return true;
    }

    public int getBarrierType() {
        return this.mBarrierType;
    }

    public void setBarrierType(int barrierType) {
        this.mBarrierType = barrierType;
    }

    public void setAllowsGoneWidget(boolean allowsGoneWidget) {
        this.mAllowsGoneWidget = allowsGoneWidget;
    }

    @Deprecated
    public boolean allowsGoneWidget() {
        return this.mAllowsGoneWidget;
    }

    public boolean getAllowsGoneWidget() {
        return this.mAllowsGoneWidget;
    }

    public boolean isResolvedHorizontally() {
        return this.resolved;
    }

    public boolean isResolvedVertically() {
        return this.resolved;
    }

    public void copy(ConstraintWidget src, HashMap<ConstraintWidget, ConstraintWidget> map) {
        super.copy(src, map);
        Barrier srcBarrier = (Barrier) src;
        this.mBarrierType = srcBarrier.mBarrierType;
        this.mAllowsGoneWidget = srcBarrier.mAllowsGoneWidget;
        this.mMargin = srcBarrier.mMargin;
    }

    public String toString() {
        String debug = "[Barrier] " + getDebugName() + " {";
        for (int i = 0; i < this.mWidgetsCount; i++) {
            ConstraintWidget widget = this.mWidgets[i];
            if (i > 0) {
                debug = debug + ", ";
            }
            debug = debug + widget.getDebugName();
        }
        return debug + "}";
    }

    /* access modifiers changed from: protected */
    public void markWidgets() {
        for (int i = 0; i < this.mWidgetsCount; i++) {
            ConstraintWidget widget = this.mWidgets[i];
            if (this.mAllowsGoneWidget || widget.allowedInBarrier()) {
                if (this.mBarrierType == 0 || this.mBarrierType == 1) {
                    widget.setInBarrier(0, true);
                } else if (this.mBarrierType == 2 || this.mBarrierType == 3) {
                    widget.setInBarrier(1, true);
                }
            }
        }
    }

    public void addToSolver(LinearSystem system, boolean optimize) {
        LinearSystem linearSystem = system;
        this.mListAnchors[0] = this.mLeft;
        this.mListAnchors[2] = this.mTop;
        this.mListAnchors[1] = this.mRight;
        this.mListAnchors[3] = this.mBottom;
        for (int i = 0; i < this.mListAnchors.length; i++) {
            this.mListAnchors[i].mSolverVariable = linearSystem.createObjectVariable(this.mListAnchors[i]);
        }
        if (this.mBarrierType >= 0 && this.mBarrierType < 4) {
            ConstraintAnchor position = this.mListAnchors[this.mBarrierType];
            if (!this.resolved) {
                allSolved();
            }
            if (this.resolved) {
                this.resolved = false;
                if (this.mBarrierType == 0 || this.mBarrierType == 1) {
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mX);
                    linearSystem.addEquality(this.mRight.mSolverVariable, this.mX);
                } else if (this.mBarrierType == 2 || this.mBarrierType == 3) {
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mY);
                    linearSystem.addEquality(this.mBottom.mSolverVariable, this.mY);
                }
            } else {
                boolean hasMatchConstraintWidgets = false;
                int i2 = 0;
                while (true) {
                    if (i2 >= this.mWidgetsCount) {
                        break;
                    }
                    ConstraintWidget widget = this.mWidgets[i2];
                    if (this.mAllowsGoneWidget || widget.allowedInBarrier()) {
                        if ((this.mBarrierType != 0 && this.mBarrierType != 1) || widget.getHorizontalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || widget.mLeft.mTarget == null || widget.mRight.mTarget == null) {
                            if ((this.mBarrierType == 2 || this.mBarrierType == 3) && widget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widget.mTop.mTarget != null && widget.mBottom.mTarget != null) {
                                hasMatchConstraintWidgets = true;
                                break;
                            }
                        } else {
                            hasMatchConstraintWidgets = true;
                            break;
                        }
                    }
                    i2++;
                }
                boolean mHasHorizontalCenteredDependents = this.mLeft.hasCenteredDependents() || this.mRight.hasCenteredDependents();
                boolean mHasVerticalCenteredDependents = this.mTop.hasCenteredDependents() || this.mBottom.hasCenteredDependents();
                int equalityOnReferencesStrength = 5;
                if (!(!hasMatchConstraintWidgets && ((this.mBarrierType == 0 && mHasHorizontalCenteredDependents) || ((this.mBarrierType == 2 && mHasVerticalCenteredDependents) || ((this.mBarrierType == 1 && mHasHorizontalCenteredDependents) || (this.mBarrierType == 3 && mHasVerticalCenteredDependents)))))) {
                    equalityOnReferencesStrength = 4;
                }
                for (int i3 = 0; i3 < this.mWidgetsCount; i3++) {
                    ConstraintWidget widget2 = this.mWidgets[i3];
                    if (this.mAllowsGoneWidget || widget2.allowedInBarrier()) {
                        SolverVariable target = linearSystem.createObjectVariable(widget2.mListAnchors[this.mBarrierType]);
                        widget2.mListAnchors[this.mBarrierType].mSolverVariable = target;
                        int margin = 0;
                        if (widget2.mListAnchors[this.mBarrierType].mTarget != null && widget2.mListAnchors[this.mBarrierType].mTarget.mOwner == this) {
                            margin = 0 + widget2.mListAnchors[this.mBarrierType].mMargin;
                        }
                        if (this.mBarrierType == 0 || this.mBarrierType == 2) {
                            linearSystem.addLowerBarrier(position.mSolverVariable, target, this.mMargin - margin, hasMatchConstraintWidgets);
                        } else {
                            linearSystem.addGreaterBarrier(position.mSolverVariable, target, this.mMargin + margin, hasMatchConstraintWidgets);
                        }
                        linearSystem.addEquality(position.mSolverVariable, target, this.mMargin + margin, equalityOnReferencesStrength);
                    }
                }
                if (this.mBarrierType == 0) {
                    linearSystem.addEquality(this.mRight.mSolverVariable, this.mLeft.mSolverVariable, 0, 8);
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 4);
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 0);
                } else if (this.mBarrierType == 1) {
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mRight.mSolverVariable, 0, 8);
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 4);
                    linearSystem.addEquality(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 0);
                } else if (this.mBarrierType == 2) {
                    linearSystem.addEquality(this.mBottom.mSolverVariable, this.mTop.mSolverVariable, 0, 8);
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 4);
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 0);
                } else if (this.mBarrierType == 3) {
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mBottom.mSolverVariable, 0, 8);
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 4);
                    linearSystem.addEquality(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 0);
                }
            }
        }
    }

    public void setMargin(int margin) {
        this.mMargin = margin;
    }

    public int getMargin() {
        return this.mMargin;
    }

    public int getOrientation() {
        switch (this.mBarrierType) {
            case 0:
            case 1:
                return 0;
            case 2:
            case 3:
                return 1;
            default:
                return -1;
        }
    }

    public boolean allSolved() {
        boolean hasAllWidgetsResolved = true;
        for (int i = 0; i < this.mWidgetsCount; i++) {
            ConstraintWidget widget = this.mWidgets[i];
            if (this.mAllowsGoneWidget || widget.allowedInBarrier()) {
                if ((this.mBarrierType == 0 || this.mBarrierType == 1) && !widget.isResolvedHorizontally()) {
                    hasAllWidgetsResolved = false;
                } else if ((this.mBarrierType == 2 || this.mBarrierType == 3) && !widget.isResolvedVertically()) {
                    hasAllWidgetsResolved = false;
                }
            }
        }
        if (!hasAllWidgetsResolved || this.mWidgetsCount <= 0) {
            return false;
        }
        int barrierPosition = 0;
        boolean initialized = false;
        for (int i2 = 0; i2 < this.mWidgetsCount; i2++) {
            ConstraintWidget widget2 = this.mWidgets[i2];
            if (this.mAllowsGoneWidget || widget2.allowedInBarrier()) {
                if (!initialized) {
                    if (this.mBarrierType == 0) {
                        barrierPosition = widget2.getAnchor(ConstraintAnchor.Type.LEFT).getFinalValue();
                    } else if (this.mBarrierType == 1) {
                        barrierPosition = widget2.getAnchor(ConstraintAnchor.Type.RIGHT).getFinalValue();
                    } else if (this.mBarrierType == 2) {
                        barrierPosition = widget2.getAnchor(ConstraintAnchor.Type.TOP).getFinalValue();
                    } else if (this.mBarrierType == 3) {
                        barrierPosition = widget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getFinalValue();
                    }
                    initialized = true;
                }
                if (this.mBarrierType == 0) {
                    barrierPosition = Math.min(barrierPosition, widget2.getAnchor(ConstraintAnchor.Type.LEFT).getFinalValue());
                } else if (this.mBarrierType == 1) {
                    barrierPosition = Math.max(barrierPosition, widget2.getAnchor(ConstraintAnchor.Type.RIGHT).getFinalValue());
                } else if (this.mBarrierType == 2) {
                    barrierPosition = Math.min(barrierPosition, widget2.getAnchor(ConstraintAnchor.Type.TOP).getFinalValue());
                } else if (this.mBarrierType == 3) {
                    barrierPosition = Math.max(barrierPosition, widget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getFinalValue());
                }
            }
        }
        int barrierPosition2 = barrierPosition + this.mMargin;
        if (this.mBarrierType == 0 || this.mBarrierType == 1) {
            setFinalHorizontal(barrierPosition2, barrierPosition2);
        } else {
            setFinalVertical(barrierPosition2, barrierPosition2);
        }
        this.resolved = true;
        return true;
    }
}
