package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.Helper;
import androidx.constraintlayout.core.widgets.Optimizer;
import androidx.constraintlayout.core.widgets.VirtualLayout;
import java.util.ArrayList;

public class BasicMeasure {
    public static final int AT_MOST = Integer.MIN_VALUE;
    private static final boolean DEBUG = false;
    public static final int EXACTLY = 1073741824;
    public static final int FIXED = -3;
    public static final int MATCH_PARENT = -1;
    private static final int MODE_SHIFT = 30;
    public static final int UNSPECIFIED = 0;
    public static final int WRAP_CONTENT = -2;
    private ConstraintWidgetContainer constraintWidgetContainer;
    private Measure mMeasure = new Measure();
    private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<>();

    public static class Measure {
        public static int SELF_DIMENSIONS = 0;
        public static int TRY_GIVEN_DIMENSIONS = 1;
        public static int USE_GIVEN_DIMENSIONS = 2;
        public ConstraintWidget.DimensionBehaviour horizontalBehavior;
        public int horizontalDimension;
        public int measureStrategy;
        public int measuredBaseline;
        public boolean measuredHasBaseline;
        public int measuredHeight;
        public boolean measuredNeedsSolverPass;
        public int measuredWidth;
        public ConstraintWidget.DimensionBehaviour verticalBehavior;
        public int verticalDimension;
    }

    public interface Measurer {
        void didMeasures();

        void measure(ConstraintWidget constraintWidget, Measure measure);
    }

    public void updateHierarchy(ConstraintWidgetContainer layout) {
        this.mVariableDimensionsWidgets.clear();
        int childCount = layout.mChildren.size();
        for (int i = 0; i < childCount; i++) {
            ConstraintWidget widget = (ConstraintWidget) layout.mChildren.get(i);
            if (widget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || widget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                this.mVariableDimensionsWidgets.add(widget);
            }
        }
        layout.invalidateGraph();
    }

    public BasicMeasure(ConstraintWidgetContainer constraintWidgetContainer2) {
        this.constraintWidgetContainer = constraintWidgetContainer2;
    }

    private void measureChildren(ConstraintWidgetContainer layout) {
        int childCount = layout.mChildren.size();
        boolean optimize = layout.optimizeFor(64);
        Measurer measurer = layout.getMeasurer();
        for (int i = 0; i < childCount; i++) {
            ConstraintWidget child = (ConstraintWidget) layout.mChildren.get(i);
            if (!(child instanceof Guideline) && !(child instanceof Barrier) && !child.isInVirtualLayout() && (!optimize || child.horizontalRun == null || child.verticalRun == null || !child.horizontalRun.dimension.resolved || !child.verticalRun.dimension.resolved)) {
                boolean skip = false;
                ConstraintWidget.DimensionBehaviour widthBehavior = child.getDimensionBehaviour(0);
                ConstraintWidget.DimensionBehaviour heightBehavior = child.getDimensionBehaviour(1);
                if (widthBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && child.mMatchConstraintDefaultWidth != 1 && heightBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && child.mMatchConstraintDefaultHeight != 1) {
                    skip = true;
                }
                if (!skip && layout.optimizeFor(1) && !(child instanceof VirtualLayout)) {
                    if (widthBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && child.mMatchConstraintDefaultWidth == 0 && heightBehavior != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && !child.isInHorizontalChain()) {
                        skip = true;
                    }
                    if (heightBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && child.mMatchConstraintDefaultHeight == 0 && widthBehavior != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && !child.isInHorizontalChain()) {
                        skip = true;
                    }
                    if ((widthBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || heightBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) && child.mDimensionRatio > 0.0f) {
                        skip = true;
                    }
                }
                if (!skip) {
                    measure(measurer, child, Measure.SELF_DIMENSIONS);
                    if (layout.mMetrics != null) {
                        layout.mMetrics.measuredWidgets++;
                    }
                }
            }
        }
        measurer.didMeasures();
    }

    private void solveLinearSystem(ConstraintWidgetContainer layout, String reason, int pass, int w, int h) {
        int minWidth = layout.getMinWidth();
        int minHeight = layout.getMinHeight();
        layout.setMinWidth(0);
        layout.setMinHeight(0);
        layout.setWidth(w);
        layout.setHeight(h);
        layout.setMinWidth(minWidth);
        layout.setMinHeight(minHeight);
        this.constraintWidgetContainer.setPass(pass);
        this.constraintWidgetContainer.layout();
    }

    public long solverMeasure(ConstraintWidgetContainer layout, int optimizationLevel, int paddingX, int paddingY, int widthMode, int widthSize, int heightMode, int heightSize, int lastMeasureWidth, int lastMeasureHeight) {
        boolean matchHeight;
        long j;
        boolean allSolved;
        boolean containerWrapHeight;
        int computations;
        int sizeDependentWidgetsCount;
        int optimizations;
        ConstraintWidgetContainer constraintWidgetContainer2;
        long layoutTime;
        int sizeDependentWidgetsCount2;
        int maxIterations;
        int i;
        int measureStrategy;
        boolean optimizeWrap;
        int childCount;
        long layoutTime2;
        boolean needSolverPass;
        int heightSize2;
        int widthSize2;
        boolean allSolved2;
        boolean z;
        boolean optimize;
        BasicMeasure basicMeasure = this;
        ConstraintWidgetContainer constraintWidgetContainer3 = layout;
        int i2 = optimizationLevel;
        int i3 = widthMode;
        int i4 = heightMode;
        Measurer measurer = constraintWidgetContainer3.getMeasurer();
        long layoutTime3 = 0;
        int childCount2 = constraintWidgetContainer3.mChildren.size();
        int startingWidth = constraintWidgetContainer3.getWidth();
        int startingHeight = constraintWidgetContainer3.getHeight();
        boolean optimizeWrap2 = Optimizer.enabled(i2, 128);
        boolean optimize2 = optimizeWrap2 || Optimizer.enabled(i2, 64);
        if (optimize2) {
            int i5 = 0;
            while (i5 < childCount2) {
                ConstraintWidget child = (ConstraintWidget) constraintWidgetContainer3.mChildren.get(i5);
                boolean optimize3 = optimize2;
                boolean matchWidth = child.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                boolean matchHeight2 = child.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                boolean ratio = matchWidth && matchHeight2 && child.getDimensionRatio() > 0.0f;
                if (!child.isInHorizontalChain() || !ratio) {
                    if (child.isInVerticalChain() && ratio) {
                        matchHeight = false;
                        break;
                    }
                    boolean z2 = matchHeight2;
                    if (child instanceof VirtualLayout) {
                        matchHeight = false;
                        break;
                    } else if (child.isInHorizontalChain() || child.isInVerticalChain()) {
                        matchHeight = false;
                        break;
                    } else {
                        i5++;
                        optimize2 = optimize3;
                    }
                } else {
                    matchHeight = false;
                    break;
                }
            }
            optimize = optimize2;
        } else {
            optimize = optimize2;
        }
        matchHeight = optimize;
        if (!matchHeight || LinearSystem.sMetrics == null) {
            j = 1;
        } else {
            j = 1;
            LinearSystem.sMetrics.measures++;
        }
        boolean optimize4 = ((i3 == 1073741824 && i4 == 1073741824) || optimizeWrap2) & matchHeight;
        if (optimize4) {
            int computations2 = 0;
            int computations3 = Math.min(constraintWidgetContainer3.getMaxWidth(), widthSize);
            int heightSize3 = Math.min(constraintWidgetContainer3.getMaxHeight(), heightSize);
            if (i3 == 1073741824 && constraintWidgetContainer3.getWidth() != computations3) {
                constraintWidgetContainer3.setWidth(computations3);
                constraintWidgetContainer3.invalidateGraph();
            }
            if (i4 == 1073741824 && constraintWidgetContainer3.getHeight() != heightSize3) {
                constraintWidgetContainer3.setHeight(heightSize3);
                constraintWidgetContainer3.invalidateGraph();
            }
            if (i3 == 1073741824 && i4 == 1073741824) {
                allSolved2 = constraintWidgetContainer3.directMeasure(optimizeWrap2);
                computations2 = 2;
                widthSize2 = computations3;
                heightSize2 = heightSize3;
                z = false;
            } else {
                allSolved2 = constraintWidgetContainer3.directMeasureSetup(optimizeWrap2);
                widthSize2 = computations3;
                if (i3 == 1073741824) {
                    heightSize2 = heightSize3;
                    z = false;
                    allSolved2 &= constraintWidgetContainer3.directMeasureWithOrientation(optimizeWrap2, 0);
                    computations2 = 0 + 1;
                } else {
                    heightSize2 = heightSize3;
                    z = false;
                }
                if (i4 == 1073741824) {
                    allSolved2 &= constraintWidgetContainer3.directMeasureWithOrientation(optimizeWrap2, 1);
                    computations2++;
                }
            }
            if (allSolved2) {
                if (i3 == 1073741824) {
                    z = true;
                }
                constraintWidgetContainer3.updateFromRuns(z, i4 == 1073741824);
            }
            allSolved = allSolved2;
            containerWrapHeight = true;
            int i6 = widthSize2;
            int i7 = heightSize2;
            computations = computations2;
        } else {
            allSolved = false;
            containerWrapHeight = true;
            int i8 = widthSize;
            int i9 = heightSize;
            computations = 0;
        }
        if (!allSolved || computations != 2) {
            int optimizations2 = constraintWidgetContainer3.getOptimizationLevel();
            if (childCount2 > 0) {
                measureChildren(layout);
            }
            updateHierarchy(layout);
            int sizeDependentWidgetsCount3 = basicMeasure.mVariableDimensionsWidgets.size();
            if (childCount2 > 0) {
                int i10 = computations;
                sizeDependentWidgetsCount = sizeDependentWidgetsCount3;
                optimizations = optimizations2;
                constraintWidgetContainer2 = layout;
                basicMeasure.solveLinearSystem(constraintWidgetContainer2, "First pass", 0, startingWidth, startingHeight);
            } else {
                sizeDependentWidgetsCount = sizeDependentWidgetsCount3;
                int i11 = computations;
                optimizations = optimizations2;
                constraintWidgetContainer2 = layout;
            }
            if (sizeDependentWidgetsCount > 0) {
                boolean needSolverPass2 = false;
                boolean containerWrapWidth = constraintWidgetContainer2.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                if (constraintWidgetContainer2.getVerticalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    containerWrapHeight = false;
                }
                int minWidth = Math.max(constraintWidgetContainer2.getWidth(), basicMeasure.constraintWidgetContainer.getMinWidth());
                int minHeight = Math.max(constraintWidgetContainer2.getHeight(), basicMeasure.constraintWidgetContainer.getMinHeight());
                int minWidth2 = minWidth;
                int startingWidth2 = startingWidth;
                int i12 = 0;
                while (i12 < sizeDependentWidgetsCount) {
                    int startingHeight2 = startingHeight;
                    ConstraintWidget widget = basicMeasure.mVariableDimensionsWidgets.get(i12);
                    int i13 = i12;
                    if ((widget instanceof VirtualLayout) == 0) {
                        layoutTime2 = layoutTime3;
                        childCount = childCount2;
                        optimizeWrap = optimizeWrap2;
                        needSolverPass = needSolverPass2;
                    } else {
                        int preWidth = widget.getWidth();
                        int preHeight = widget.getHeight();
                        layoutTime2 = layoutTime3;
                        boolean needSolverPass3 = needSolverPass2 | basicMeasure.measure(measurer, widget, Measure.TRY_GIVEN_DIMENSIONS);
                        if (constraintWidgetContainer2.mMetrics != null) {
                            childCount = childCount2;
                            optimizeWrap = optimizeWrap2;
                            constraintWidgetContainer2.mMetrics.measuredMatchWidgets += j;
                        } else {
                            childCount = childCount2;
                            optimizeWrap = optimizeWrap2;
                        }
                        int measuredWidth = widget.getWidth();
                        int measuredHeight = widget.getHeight();
                        if (measuredWidth != preWidth) {
                            widget.setWidth(measuredWidth);
                            if (!containerWrapWidth || widget.getRight() <= minWidth2) {
                            } else {
                                int i14 = preWidth;
                                minWidth2 = Math.max(minWidth2, widget.getRight() + widget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin());
                            }
                            needSolverPass3 = true;
                        }
                        if (measuredHeight != preHeight) {
                            widget.setHeight(measuredHeight);
                            if (containerWrapHeight && widget.getBottom() > minHeight) {
                                minHeight = Math.max(minHeight, widget.getBottom() + widget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin());
                            }
                            needSolverPass3 = true;
                        }
                        needSolverPass = needSolverPass3 | ((VirtualLayout) widget).needSolverPass();
                    }
                    i12 = i13 + 1;
                    int i15 = heightMode;
                    needSolverPass2 = needSolverPass;
                    startingHeight = startingHeight2;
                    layoutTime3 = layoutTime2;
                    childCount2 = childCount;
                    optimizeWrap2 = optimizeWrap;
                }
                int i16 = i12;
                int startingHeight3 = startingHeight;
                layoutTime = layoutTime3;
                int i17 = childCount2;
                boolean z3 = optimizeWrap2;
                int maxIterations2 = 2;
                int j2 = 0;
                int minWidth3 = minWidth2;
                int minWidth4 = minHeight;
                boolean minHeight2 = needSolverPass2;
                while (true) {
                    if (j2 >= maxIterations2) {
                        int i18 = sizeDependentWidgetsCount;
                        int i19 = maxIterations2;
                        int i20 = startingHeight3;
                        break;
                    }
                    int preBaselineDistance = 0;
                    boolean needSolverPass4 = minHeight2;
                    int minHeight3 = minWidth4;
                    int minWidth5 = minWidth3;
                    while (preBaselineDistance < sizeDependentWidgetsCount) {
                        ConstraintWidget widget2 = basicMeasure.mVariableDimensionsWidgets.get(preBaselineDistance);
                        if ((!(widget2 instanceof Helper) || (widget2 instanceof VirtualLayout)) && !(widget2 instanceof Guideline) && widget2.getVisibility() != 8 && ((!optimize4 || !widget2.horizontalRun.dimension.resolved || !widget2.verticalRun.dimension.resolved) && !(widget2 instanceof VirtualLayout))) {
                            int preWidth2 = widget2.getWidth();
                            int preHeight2 = widget2.getHeight();
                            i = preBaselineDistance;
                            int preBaselineDistance2 = widget2.getBaselineDistance();
                            int measureStrategy2 = Measure.TRY_GIVEN_DIMENSIONS;
                            sizeDependentWidgetsCount2 = sizeDependentWidgetsCount;
                            if (j2 == maxIterations2 - 1) {
                                measureStrategy = Measure.USE_GIVEN_DIMENSIONS;
                            } else {
                                measureStrategy = measureStrategy2;
                            }
                            needSolverPass4 |= basicMeasure.measure(measurer, widget2, measureStrategy);
                            if (constraintWidgetContainer2.mMetrics != null) {
                                int i21 = measureStrategy;
                                maxIterations = maxIterations2;
                                constraintWidgetContainer2.mMetrics.measuredMatchWidgets += j;
                            } else {
                                maxIterations = maxIterations2;
                            }
                            int measuredWidth2 = widget2.getWidth();
                            int measuredHeight2 = widget2.getHeight();
                            if (measuredWidth2 != preWidth2) {
                                widget2.setWidth(measuredWidth2);
                                if (!containerWrapWidth || widget2.getRight() <= minWidth5) {
                                } else {
                                    int i22 = measuredWidth2;
                                    minWidth5 = Math.max(minWidth5, widget2.getRight() + widget2.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin());
                                }
                                needSolverPass4 = true;
                            }
                            if (measuredHeight2 != preHeight2) {
                                widget2.setHeight(measuredHeight2);
                                if (containerWrapHeight && widget2.getBottom() > minHeight3) {
                                    minHeight3 = Math.max(minHeight3, widget2.getBottom() + widget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin());
                                }
                                needSolverPass4 = true;
                            }
                            if (widget2.hasBaseline() && preBaselineDistance2 != widget2.getBaselineDistance()) {
                                needSolverPass4 = true;
                            }
                        } else {
                            i = preBaselineDistance;
                            sizeDependentWidgetsCount2 = sizeDependentWidgetsCount;
                            maxIterations = maxIterations2;
                        }
                        preBaselineDistance = i + 1;
                        basicMeasure = this;
                        sizeDependentWidgetsCount = sizeDependentWidgetsCount2;
                        maxIterations2 = maxIterations;
                    }
                    int i23 = preBaselineDistance;
                    int sizeDependentWidgetsCount4 = sizeDependentWidgetsCount;
                    int maxIterations3 = maxIterations2;
                    if (!needSolverPass4) {
                        int i24 = startingHeight3;
                        break;
                    }
                    int startingWidth3 = startingWidth2;
                    solveLinearSystem(constraintWidgetContainer2, "intermediate pass", j2 + 1, startingWidth3, startingHeight3);
                    minHeight2 = false;
                    j2++;
                    sizeDependentWidgetsCount = sizeDependentWidgetsCount4;
                    startingWidth2 = startingWidth3;
                    minWidth4 = minHeight3;
                    minWidth3 = minWidth5;
                    maxIterations2 = maxIterations3;
                    basicMeasure = this;
                }
            } else {
                int i25 = sizeDependentWidgetsCount;
                layoutTime = 0;
                int i26 = childCount2;
                boolean z4 = optimizeWrap2;
            }
            constraintWidgetContainer2.setOptimizationLevel(optimizations);
            return layoutTime;
        }
        int i27 = computations;
        int i28 = startingWidth;
        int i29 = childCount2;
        boolean z5 = optimizeWrap2;
        return 0;
    }

    private boolean measure(Measurer measurer, ConstraintWidget widget, int measureStrategy) {
        this.mMeasure.horizontalBehavior = widget.getHorizontalDimensionBehaviour();
        this.mMeasure.verticalBehavior = widget.getVerticalDimensionBehaviour();
        this.mMeasure.horizontalDimension = widget.getWidth();
        this.mMeasure.verticalDimension = widget.getHeight();
        this.mMeasure.measuredNeedsSolverPass = false;
        this.mMeasure.measureStrategy = measureStrategy;
        boolean horizontalMatchConstraints = this.mMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
        boolean verticalMatchConstraints = this.mMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
        boolean horizontalUseRatio = horizontalMatchConstraints && widget.mDimensionRatio > 0.0f;
        boolean verticalUseRatio = verticalMatchConstraints && widget.mDimensionRatio > 0.0f;
        if (horizontalUseRatio && widget.mResolvedMatchConstraintDefault[0] == 4) {
            this.mMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        }
        if (verticalUseRatio && widget.mResolvedMatchConstraintDefault[1] == 4) {
            this.mMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        }
        measurer.measure(widget, this.mMeasure);
        widget.setWidth(this.mMeasure.measuredWidth);
        widget.setHeight(this.mMeasure.measuredHeight);
        widget.setHasBaseline(this.mMeasure.measuredHasBaseline);
        widget.setBaselineDistance(this.mMeasure.measuredBaseline);
        this.mMeasure.measureStrategy = Measure.SELF_DIMENSIONS;
        return this.mMeasure.measuredNeedsSolverPass;
    }
}
